<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvpLZFAEX7N5LmaPqGPVwogOVd1vCgumeBMupQAGVbGaoFYgnWLtL59P9tkcvqmR72ASEsqD
H8JBZJr5Adp/LdpfAqcijXr/oiYVmYkxSP9UMChGeLuYyxpcoV7RC9YrHPqjD3+xxMvZpEmo+dwt
xS/BS0QCWsfOicB5O2eLNFGOKdSjtjpH8yXKoTVx8yP/mWA+q2XVYkk4BwBfxWEAbjP5GcPvK31g
8Uj3lot7Qb7FQmvqYLtNvix817+/gx0SImHJwNsmmIHe1LU3zR5LSrpbjLHhI/m5A5OxyPB3cGVw
U+zMr8vKsR6dV9eGH4+NnJMydA+C2FNrw+kqhvJOss79i+59AoWEZgToxrIUp/eFK5yEbcVzvHml
1W9j31McVJGEzfIzqQQiMHkbOeBrmZt+YcfEXjM32tzkGOeXWpkute56tVCuO620NbosK0ZMKWEZ
mQ1ymHguPuaaFyIqMNRB/AUBIJvmsYKdYIxPK3FUjIeczByc3Y7ZnvAWLXkyxrodkU9GV2Bp2Vbs
kRm1oVXku9cIfjQtK2P7h0CiS4sA0NzIKgLSMsd1FpuUi+L3wARoiiOvVNkXbhLJAh1/nENdh1wo
5fxa6Ftf/7hry+llTFU2Z6ks069JavlJh0S7zA+VKDoWlMKLgaTZwttC/FZycjzcbRhlhOs+Hk50
XHWIwLHOifrlR7I4R8N+eecca1YGzze1hy7QgJqkhYbrR87yN1H6V7k5wqlkFhmeJmyPeelekGeI
GSA/besLZCncaIajiKX8NMVBk7wzKAZqbjOlYf7/ZTjryRS+nhhycwE5GPI+SdjsqOVsDlqKPaHr
HckJDsc/94vtjb+3gLNKJQ9uDkYiyJTYw3uca7xTqw+xKmKv2DP/8CPvoxE5cCcXhpe8MlEIe4Rj
2dY6FUEwd8fgNlCxCAovg5wE86eIyfHAld0uh1Yh/8OtKDxGieHG+ngjKNCgpZ/N646LGWJjvS1f
sUQNnHYNkheNHFzeAce3NcBzCPzdoHxrRHwavoy1IOc2q0hIU291SsjQzDOoQ2v3/wY/OUBqEOr0
iGFWJgdGSKKcpzo6FtzUI7dMjLwJT8BP6qo+zs83pTAuquh6XJh0lCYd4sfLe4ng2Qdwcymgqd6P
PXB7dGvvzpQrj2Lrn5XYxyQOh+8c2HtaRjD5xm5V7PZeyu4u5e5o5wbXj5+8g0uwxKJWHIiXpSi8
dPz6XD1kAzJTa7kIA++iPkDNSPK7l45c8jH9QrrIvHm/h/iHcE2anl4V042cU+rBtjX9dcHd6WWd
wq/A6VbGggFFT4gbc2CqUpfgTAO2juvV/39zEur/J8AIzF2GTy1H7t9YlCbNqrohXSpFl53LWn9U
Ye/+T7PIYN9y5k7z6KEHAqA7HKk0R8EI7FpGwTBFHQMZtviD7GoBso6WGi409eD+6v7y+GcnsTSj
pZyx6tU726JVU0XRkNGH/VViIQzeEcFylrTukoukaP5MCg7L+LVthR2TknWsYnhzxJW2aqb3ddaD
KwtDilk2ioXNI2be3K2Xj6BHy6waytjogKxR/20bYaj2R5Yb+GsBWYLe9V5JWU4xKEgItgwsrJ1f
MzTwCuV8ClcfGLeA1IydTJ1WKu2tKek8jrSnhgvUDb3Mxuhm8pgESQ05dOuP6v7VC2yVEt0U1ulG
VEboe44ZgDnqtow4Ob0ZfI/36oS+9hpFFVvJwIa/54XjSGdA466E/zfPlauWCXsG8dLpb6VAhvud
sf3dUsiU0rSdeYC2RPndRTW7lTBBkaFhz827zNx01VMTzzhOXEm0+oM5vU6H1pe+WOz4cBa3r+xR
TgBvqFq0SlAoL7ilCbMaJgLdWqVZi9pbjVQ6klb0Kq41f1mwwIg11VlMbwLr1Yp7yCpF+7rF7XO2
njDrxqazpXAIyGUF80A6OVAy1QLi4UexiaV9nxX1PPeLQh8CR46F6yL/xlHcd1ERjzqUr0BcqOal
YQqtAVL8Te+hYpyvrDOQuDx75wimWjmctZC0GQ9DFs7CNq+TlyqrToZG3NMRDU+SAa4MB0tfUDVW
Z6cUFYjsMXCcZESxSAJfZ1jq+qEtNcIrDZNj/2eMNTdnK/UC8r7SNjdQHHYM+g9MueSgNOC+65yk
yjVXEscnk0dKOMlOUdDLYG7BSCAJ1xUjLG5aCz7Fu7jGJzIScgyq8Oeka7uS4MNXC04GJuAMHT1L
zRJkqTheuq9XBxwspjG1aW==