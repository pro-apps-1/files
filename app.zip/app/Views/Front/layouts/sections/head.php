<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsFcLisbLAlYi3h3xeXQBx3Lm5juoU9gz+KQZ3MOq3XHUtDoPsRotiv81PhDB/BRS+meu6Ew
dQNgVnQsmf+9+qalYb1TScIoM1mBywLTSHuEE0EsLJKfukm9ndPetGrnKCxi7SPfgV+s25z4zRq/
AIknvYYRSs+PAG4h2UJTEaxnsUpbGEPg0NTc71jOA0vPy0ZMdEkcdDKT3Ow5aaT1NupCtHHNC6i7
uDlZg+6UtPxH8vQVNrP59IjUDphHBdadAiy+U15yXavASODAXtEDfJjwW1HzPxr8R3iTmBkPStGz
vCpkKKH+S3leQ5wXG5aBFhfmEfM6Q6IEZNdwSGtotWI2CKw9AUPTFZGjo40gyBiKsn9w8EVcIwW9
/p/F8WhVK+Znnqd18+6Mzv4d2725S+AKxucxWwLwd+tbJgKVeq0PVe+/4w2aBWGcomN1Zx+B4n8k
rN3rm+sa9zvArqZotZ5JS+ZdYWE1trvRO+k69eipYs8+HKt7foYEJ327k+n7logRg76//LRRzoWo
mYsjwewaa/yZsuP8AHysgqlyY2aN3kmWddKj33h81hKrIVHzbyGbEYZXxRdzKJaGoHwWSN/A5P6B
xSBgvXtX7vSa6ERLS2OOYjg9XP0vA6sOGW8Zn0fOmRa4SQtqwpdkLsHt/pqecK4vQdFinaJH0o0R
3i1/5LwGtoF95WzX2cUWa1aSj8O5Tw2Cr+4TtbEFCaakPXf7/3UZimTCBhtWWudMl/9rYXD1GW6G
rWH0CeE1D/m5pygfP8szjMuBdmK4eTvtoZJWo2mU7MO7iJIFGOq0XZC3BI874DR4U8sLdfyTxq7s
zW/exaux6VEoUBMSjjXyzM2F6ZLe6uGaUfhAbrpHna8iYMMl8akWaD8dCEeFeG8m35cXeDz6INZA
/CSfn8z63DuQMRr0+e7PLM5e1/tXGOycGYBvjxQEGiKM+UgkvK/I1Hg4qnzsy7CC+Vd7ubDZI4tV
dG7ZMzNJwX3KKYLPzK//tJRbPJPC0fvTrazcIZwbzlcaXiylk909U/7ZvLGoTRUr9qxm9wmM9Ybh
renrmnRZ/CUUxoSVjzOoGutt9Vpn3A1k9exUfsZElUlFKoljTf01IhwQdu7Lv7YZSayFqegNPbN/
0NbZnVkHmIe3FZO6Ej7qUillkxR45l9yC1WiVeh/6RWT4/e+HfNxrKCTrF2a43LttbOedmyOiDX8
KyBvQ9QfNqN/Nl+d0Io21v/GZNmA3K9W/c7OAy+UXGf1HFLAyOZXkKuKNyQu/n7g8fRZyKFBVbHr
AnLyAisIt0dPxvdRhASRW5ELl3F3BWbEU9L4K85HTTkagL0aqxxSGLFiGVy/GXL3hMZpeJbLxbOF
VD4c3C6wTkGXmx917wHAJRzspL+hkEmVOYjJ4r1MQbk9Wkd1fYmRqERIfXQUOVoX6M9BZVa01xst
lolJo3Ephe2jLqdaocyj3GmNrTeOVQ9TC46UoP2zvV7NdcPQkljSi1hc/JNfy2AqqAfalBdrTFyu
TU8+npYd+AJTCYsU6KtwGChbQwOgtJI3wQLfPXt+Dh3yU/RMWgwi4iTu9k4u1lgq3P1vfE652k6Q
piX13FKXmca4OhhWQhNWEAE3OalOCu0UAR/LY0vUBLenOrd+HJTlo/JmggltASkV97yF7MEVUBu2
s1XTfVr9kDqpK+dADZCO//bg2dfilkF/AcvKCE8Ek5QF6Ir8ygRGbl2Z9dAQbzDFGeSbeg8BQcei
PlGqgZaBrLUfCCh7G8MkYAGTRTGVsGJCvI3HfOawg72puT05ih5ll12+XcatEmGd488/z+e2btks
cOqYBAg/AwbZ6W0B/C/metPDvBsPrte2gl1iiE4M58EILcy6o8mYLMYaSVqPySYT5XaG010npGBG
ncryPnnOspqaqNbLZW/w6CU/4jwDqNAdwzc48wqtx05pgD+IuEG5orNYBYnDJHEmTrmPjKx7M12z
io7I8VRwc5Pf2s5QYvDawOvJKjXkI13Wsm9gKfblUIfm+BW2tONp/G32rJbwejN/xK+DRcwcUJHZ
kqI9kCvPh4EMuPFEUNkuTheW9FwhzYQvdAbJBR/QUWARYMZrgUPJ6O4egx0XzDOHEovdx4t5hKG9
XzjLD1ZWnHnz83djR/zSi558azNViuHIxRPVuR5kUafqcEkgNVJvnOuU1pJxjUit3dEydukP3103
Z3G7gDx6Wk0=