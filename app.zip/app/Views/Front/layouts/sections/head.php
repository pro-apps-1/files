<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPz1P24PB6V5f4eMTPUFI0HOvpbh8QtT4TV+SlzfpUCp0i0/KxfrH9zlYZT0DMMZzOlYVVFa+
928APQ5LuHW7uwVY0u/iBFVHXEM7Vvkq192oi9H/eqrKnbWwrNwr86bxcc7v1YMg764rXJkdVWS9
hyX4CzMmhejG0gKh/v+0c5Nyc8F+McJXOj3rW71Pb0UCwCjKXR6SEL2oI3A52pRVSnyInNX0LjWK
N376GEnaa59/RzoAlml5f1joDW7jNDGH9V65fLRsZL3HKx83E6zV6oB3Cgh5Ps85h76rBXB394z1
cH58PEp9m1jS5bK/B5mDlegkplE13lyEGavJtqsBUWIxBz2Gf2FoCEUCnda1RpxtxVw44De2xmon
dYdaOOtUSxd5KzatUrib/dE1KvwTUUTF+a2RwZD5JzbSWUzneqyr2xCOX9Df3PXfObn8wsUCE7eH
WlqfgvtQgnGfd3+kvJvMDBCXMToFrOiOhi3Zn6xSxBh3XRqVo5A9AntQKRV6kOziMePiIxK54Q8n
96WsiBfyIOgvvb9eX/aDgvQjGV1YkHfyD8rW6QO4+wN9YMFpkWtDRlfLVm4z/dNTnfGDWHmkdfrO
K5JpabSXJyXtNl83ouHaCn8JsMMCCPHN6UFDDKbeQWM/Ip5RtbL60btqOPhskfTvYo6ZQ/4YkFlg
2G2lIqfYTa7y3wPs7nMFSAzjUTXJC0w3aznxo0eun+CKWntB7VLIv3i3nPOmOiNWBh9dzoN42A70
Q7MPzxdxf81AswHt5Mu5MnHs5tUXazelHZ304xT2O/1Pw8cRe4lyeXsOjS7FfJA5jv5nx4LSuK4s
l2YBdWI3VQ6zUBVh/DUUTovHZzqENq+BzXlX8282VQBrUHJjZt9W9Nh1lNqcg5XTa8FBp2uuSMlH
J91tK1n4h2fC/uwpAXO4uQfL1Ra6vyYCU5sAl4H6G9i8Jo1eI5y1EiESFe2SJTqrCtssM1QFzAFY
89vcDeok4yGCQa+qVfA49x5gjceP5GgWMcAHqjNAVM2Xrs+60kBIOlVC0w/rfaGDpToY/33NTVuB
wOXOOHPBvZh7liDHXlwCrw+Q28zO2v7P77QcEDU1YNQEjZaZh/0mcuZMHrglMkpag1eOdGumtvot
LYcW/dV+p7ueG5LAQrD9/NnsK4eiDamMQUuwjAiW6vpQEflgrFQstp/f3Hx9vLpHLNc+mTuZZR6Z
we9VgFFliR68+y55gJx+1Te7V7XlZwHgIgyC+TzjLCceIwe3DhPAgvtuucoBdjliPr4R7uM350Wm
++DZVIr4DDgwbLhSH/uRyj52ruP9JJ9X0r8DZVS1boyrG8eLZ7N4ne3OSkUigB/UpuHI0Kh2GITg
6cVrq95Q3EX0nmmM3xhXqcrulV0sR2U5iYZLyzveso0FbYVQegVGgrWfy9yQQoBV3gk3/l3U8fdU
/vKgrTvhNyL+T1ORkwc9hX8JBi+Hf4cPtk117z9PZjfo0IGtKQGOXg5K81TCcD+BSi3WiO2a+RoZ
5ljbwCiwdJkcIDAnVIQhVBHmpDsFj1DhnsgzwO2u+Ymwu6qT+QV87jaU5dwyT9mtfe/U/Jc8kc1X
UkartwpApBlackG5tT+TeIyFTdx9JkcmommUtYpdubAJ47Cl7vr2a8dJcGYLTCEIIH4Nu49pp+iH
+2KoJGofsE7YJq7JeQ1dp8L5FuCh29R8I/XdQe5D5BsUytXZglDLWFpFMDTnJp0Kt/U7sOW9N1aV
QBou/owwLGR9uo8gjDuBvRtN9QwI9nKGoeNEUxyHwWwCa10NcVwM9KoDBkXxYg0zicPXKWGJJQ49
XPECzcjHO9t887w8k2G6+xIxREgbgpP58XBguuavV9WOHz6tDU227Ah+yGbLnbaz9Q/ekMvK8XJf
Xb5P3n2MMjpA1scE2HUV/fXfVB/06kHh54arLotJGy1fY/kJiRZyGHMOp6VymkdlpXZRjTWzgyGf
A6HgCxwf7fmlH5TiM0HNeuj48IA53h2B3vOeOWXvT2RSWeZ6CuT/PgN5IX9k0xwirNe/Qz3GBCvz
bf0300Ose16d/EBk/wuwAyjpfvXfSU2Ig7urxN1yT5kF8anHRowvpElxjuL5PlC1PW/JO9MdMqfS
ceeMHq1mBS7JKezsAN9E4G9MQQe1L/mdd3lMyMILuwTvspCRU5rxCrWwGi7RoUNr1F5Yb9cgjhp6
gv9qodpytTLwdYEQ6VUq+cw4i6VFtOq=