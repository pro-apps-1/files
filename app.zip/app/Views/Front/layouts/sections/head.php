<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtUJR8s6JLMZNr3vhWvvSI4l7bVlNtc6dOguZif/ToPYXk5n+xT9+FOv+E8B8qXL7BTmnDYd
60JwxXvxh4DqwsMvijPbthuMtBB4FrwO3CclUSpPX+Sbi/I1xJ/g4dtI85qgCIw++XwLUG3k5FUg
efLZ4S4qsbV87EeYuQhrrU2zhIhcyv+D3/EuuZx11Hj0tZO1V4O4x8ep8VpdIULuhWmXSCsW0ayY
VY8G+vl8kAdqqwYy8BEoamQg/4+CyNRoBPkuTXGh5tW87FW/i0pF3kQEonLjSZa7bB+oQx5gdVnX
cbWL/s48OYb2r8LVgYyWK9titUZbuassuO6VYamjjroijQ9hdOOTyOACjvYZFgo5l7OXw9llCeg4
VNB5x2mEsW73ufyaQcdiJXk+39PargbN4nmWdslYZcAiNOzAhhj+X8eUyVoRyBB8aj+RQf/9oXA6
02QA+Cmm8QGXC+fCkh/c1JgztEU+DtO1WBJHa51B/CIM93rxsWZ23/IqsuuRtC6DjZSxmWCvNATr
A5CPHrFv6s7bjPF9uFwM0UNetAbTsHOxBgoAvo/h8yw9gxoUuAtKXVD9NBy6Zguo3jiQ1PdN7wzZ
p+W93grGpeuULEBhIaLDAmVOEasEKuf20o2+XPdyOMvtyyPYxgZCGHWuDe9PBbcNpJL/fqLVEMWi
oCCcLT16Gh5qn8lv5A2nes3dMoIFkNHp0vXqiqmWddhjMpztl04lQsZ7Aqx5qvH7ZIDzP6zqykrs
LbIXxdxD5/8AriFoTEjm2ShP6RNHJihi5wBvBJLd1jOuOI6736QESo+7nhvKg/hf8hjKziD5G7Gj
1Z/QhBHRhzVTJus11Lx0higtfkgbqmmoeU98ktavIngKffyujxxWqb+/di4LP01MMpMJYw/5Hox7
gm1Q7Ua3YyvCYKPo+mPs6+Eg7SSXTX7Yq6uvDlVJgA9jrIueGhA6unT9i6kMkywBLYZ7hGFi82oo
E7nrR3CCNIWIcR2v/pqHwggCHnQmLolzHgbetGb3IFiRWTFdQ7pXtxjWBhUwAcrTdIiaR88Rf1Z+
D3VtZydPFST6HhW2enLXgg/sU0nBkD39jT9wzqvzSLO3cEEZoGvY8X6ugQTPObqnjZHZVUYhBgEx
14Vm+zYOD7sHktj0iaOpLylsFSr/n9RcEcdu320IALjTcCb5qvni5TjKl9gcfOH83KEYCrVo0qLq
PktpnubaRgCu5/KBjbvGzZGkjRfR+ZCcr3yH/CI+0TWWmpKtv/3UUbvtH0obtOXJL+o3UK64IPIO
DGgoZPHJ9GfLqThOMwi9QDGbQw0Y5ACwS7fa6Fq0ROt6z+hDDjCvm0bRd4q2bOrxetUHzfTnT5zI
Uj497Sqw7hgw2tdSgiiByDbHLwTJ57SutjC8rIxl8tPXxjChc6f+NOHxuCfzk0/uVTAwe77LllSC
ftMgcAN5ZTAzToYYjaKBg3XGvX6ltZfWg2lHtozLohXvq433is9GgWKgVVLLYcTLrDdLCFkhafgg
PlWmhc9S4oJxry1kiOxo41wnH2+bWIIHWZSwGR0drC1hWPq2VxPNIy12t94+tCc6iXMsgV4rcr/R
MfhDp3Pq8g0zyHZs2MfCOdGLmsJdYd4VvBlO5pbPX8NzTAtucena39LTyDaLtbMEUDn1HuGv5He6
yz9xzKPZLKs1dLlzKIwP219YNXQVas6JkpWuzT97dTl1to1R3zl0UqFCV+zQzw+l94u1jgfZkM/c
rhTI8um20ah8q7iMs4tuLD4sttnmNKcjmY6OW0WKAG7hcZax0SRJTs2SOY1l5utRgXM8lYbzdP8u
JGLCMfaBDFQUhjUnXNvoYQzIzitJq51hXQNU4DDVXRKSVbICtbvvMtc51Y4p8AyKOF3zn9Hbeqcu
Vlt0fmEoldyd/nmF3FPXRmVsCp4RU5H16xr5Yw7V+CGLSq9fwy3m0w6UkqMIL7wwOEHsdmwBC7jF
IZi1Vc4D37Q9ZnmpiU/rMmfjs0j3WjE1Zr/MgRm3dbX2nrGN51vF7Uy4Pc3nzgUB17EX5cRvu49j
pzAJdzbmGrQ8u5/iMDVmxcRvMb8OJgOg8uYwDmEphkonBmJT6Jx31yToA+hGq4gYFQ1J+MZ5HAOz
olrx4KQt/BZOx8IMqIMqXgCZ6Y7WLPiUNp4RjXR2tI+RXe0IbQqpkW9n