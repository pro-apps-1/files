<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPtOhvPYvfTtVHEXmkzh58aVp7BoAsXq6Bi59Ldqp3ysh0VlXsyR3rTP3BD6mRelhweJBH7++
1jGWtD4JgcbndofpYnRLgXLpipFzW41Kvvm760/Eu/M5/iGYqdqkGrtiz2vA8g5kg9kqP+yXP4VF
1diFHU8Pvw+1YdyXMidF4Smv1dKjTJc3fU+XGcCkKzIxQYz85YAbDg8+pOYaNhWrv9X3peFLPhJx
9Zw36u3Ho+BUCxKPo7IQLIBsmIGd/XLtJ443csxKLL0DZptD5Sss9lVne39sQe1ihEFoS8ANP/c2
WWT7ILolFYYPgRi7ytrR4+SwJHfZL4RXnpa1dm1LCfiidRtZXDT4tDu9XbupSOeSgsZEIahTnkFX
U/Ne6g/txLzCYURVLYV484vQwqxVcp0sNbuJ0vacqUVFp2cC4eJwkubuRnNvNGzpI1sKYoWCn2sF
nba1qnIEBKcFHqcCqwvkcqLcq33JiK14BkTfNdnDnoGdIaAFUv3SkLdImuMfTotX6TD2tmnJZbH+
qcwq44CMrEC4QPRku9JKq/W155+jhrbNhQzpT4e9dWYkvvEjlfm7pa0BMiZO7Ho+uvsp8tspXN3a
PozAgymBPxHhx53GP1pzfy3s3R02VYnSljLAfglpQD4twmNfK/1djVp3YQfDeLd5osFXSzlmMTX/
1xAIgKhp9q92laNtUyyJKZtKusPDqoE9YDGxpCA8kiS5CTJnBpC91MRechTQDzfwP+AH0ysZEfkv
3dyKO8IlDqyqLNsIC98rSkSgSuOGxkVLmPd2dTcrvJq0yrs7ZdBnX735sGxrQYuRgyODLJGO8Uc7
XA/5eSgH5E0pWg51qRIwzG+55Sp4+PlWTFedCPyNM60MQmsJssKzdL41mGqRB7wOs5U7Tan9iRbn
+Hj+59Wo2u9fVIcxpziKpVuTQgJwzrfVzEQgbjmfqhgEpNV+mHae6nmn+p9S01rV/olWpgzFCLq3
qtpHPJMGMYM4RrJ+SsXEo4jXrWpI5dwuWcbvY3MeJ/sniLV9kvdPRSGsPPmearCNrUXdsw2msIr1
6cJ+WfuDwxTi8fSpB09i/PO8CBaH48YPm6QblbpvoVO6JsumY5TCi3XlcnHxjUjm/VaSxZKcWVvR
bm3CR207m3QLK2M9qbrw+gwOS+QnKO4DchUUrTnX7m5Ij07Sr5sksQqiwOWBo2wZPBJNveG4pSG2
XLrH94VHTx33toLrIigZ++wTAuAkkq06AlU4IREtjQqc5NK8KaL/WV6bYG2wdBvS5lnlOmMLiwTI
kLzuI8FN5mj9BMVrdr2kNbWOsEmG/ZWl9VIkiwRL1lpm/bcco+2ieIOee0dOKjVbvL3S7quDYPux
cMJcDbBuwNPdPSirSisXlF7zFfLMpr2bZniM7oKutaQt2K5suThBtya2fAHw5JZE+/Qs3giVOfsA
WpG7d6JJB4u6GbNr1RZZNBU+K2fA5x/ygtXi55oi1pJI/BdbU8TQMOptMcTrIuktsBSR0+lRq1Bb
y7oj9vtMYSrciTWQsNBbrGGfP8SF7CPJRTrODgxR+zjYhXjSZWC5RpNNhVSIfEaBc4NcdbXCJrxH
2k3NLIVzfiqgfGrvXJlh+HELRAvR6Kcb0d49p9p7RHHPrf9OVoV1kYyEgclGgBQD3MNZ8u0KQPUc
UGU2VRebFxAn575rg6JyXMjNHu5m8xg+m76BFGh5RRjE4zBOlJFSIjAjHFG7pJxNYXdqyBP6W46F
a9T029HVvKt+t/K0WF9n7Z+ie6sWcAVlOcXZfcq9E5hF7NQOwBzY9P0/O9KPe97uVBErNb6BFb+o
elx6xkCuE9uTnt2Eshec7BQMCy7J7kyLPz7jzYKF1SYAUxMZsTeGBob1KfXtGR+7xwfVs1xHFgU3
UZVSyKn3he2oGYpvgOyLoVPfzUJzDECdWuqFY59natgHZ3JmmHIAbRwQtBYBjaDtZ7TTexGVUWrY
kg4ml/GJa3dibAc6IpL2SoUSusDsIjwEZU4VSX4EghQ4rvsMw/uKB0JwMABbrLTdu8WQ6Rw4v27u
ZYS1TeUdEapyzQiGJ1zsNn5wWobVbcAjZhJU1ur+GANkjJ7qu4BHIwMO+TMpVmvDTySbfVo0pvG8
1LAKNKAlYBcoTfP8s2+D1vHGkAU91El6qDY6j/szTo0=