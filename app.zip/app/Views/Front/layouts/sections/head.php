<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrtlJbFBRxDaaZFRS69K4cdu70e0M79YweouUqzEV1/mBKBCuCNyJ97yB84jhNRTiZHeKIRP
gzdYyQMIJFAtAcEOA/jgXsA6sfX4vPKVvXsL9Aam9quk5qFglqkJfGDSr/NWtPs30IXzX47Oxfpa
A2cLvRpjoy+u5kyuixNudsRJtyb4SST2LS/QHGllUGFuydZSbETor0Opxl5e0JBqQT/vAYs4Wb3t
h7GTvRNuwm1m1zl6M8qHxs5RmPdTd9fuefzFB25t6JBBuRV5iQSE4ED60+jkNq7f7q9pMv4e7Qvf
4Jr8j1vICTQJU+n3nURMtZqga27Th5mDbVad51NeU3t1VLZAMuvN/C+5ufHkBim0iyrBKypbJ/lU
WATFpxOAMKK0vJguTbk/XkUhzEKTzGOENma7UanORW2tgnLj3tq2cmaFgyCkdCAMGxz/CeNN8LiO
W8VnT8vDrT9pBGoRtgNPFMPqj5DavMIQLCB/roPlBXjCKbEEyi/25zbrXdwyAwgDQni/iH8JXsKq
sxk4Cutm5ylMUKQw1OWT64gT042ecpg/HcmfvUtp1NrQHvD4GdQaBujQ6VBHPNQNMFr/179NhlMz
C04wwM7cpvrFUZgeHb6gw2kHpu9Bu5ub41lFVjLvdVTTaId/nIEsRgSAnaY6BAy+UazbQYmWgwUu
Dc4mb27Uv8qPPt6ywPChrlzUvW3iG7K/SmgZiNJOZSZx5qci5i4EU0ZQiMH/ixFy3rXfaTk7+NXX
6o4OQ3uoaerScBoO2SHKyoqtpWTBdkKRp6pRCG+P8+AASJTqI1D8Ly/K3mmt7JMkvq4VkC3iNvEl
Eqnhhs5Jy+7I5pX/y4vHQ09l1vbVXxthN1dTIfAZpEuA9pX/ogg1As9am1nVjRV/U5frGQv+NBfl
CpdLcoYSbKxtYgmj9r04aQwSgeSJCNGdBueURB9DiYddjJ8azQnGUfAxI3W5tZVlQpD3102WmyPq
f8O0lCRDDZ/jDUwjacjLxZQOxMSncJga+RC1t3ZrAKMGk4HYHOsvPAqwP5zg7ObCVu/JCPZxn2F9
augzAaioCRe4ic8w0hkMzrc/23FdLuzkfyiMEmv5GeFKKA6TwqxyRUdiONvlCkiG9KnAnCsEICIm
Va5oW9zONQ3x0jN7GjPFjqvKyJ/N8Tq/JZk12qDmt24qpglRAyl3zk5JPVL10pLm04mUxE4HeRS/
JHz5tiYGQrqgYXzLZE6tLWZj49G1clMd3OJyltnlFk+7g6pzCMZbI7wGM1vIapI1iRrMfpHSyRmv
Hm4aI0y2b2PfLJFWBoh2WmTqElNJ2JYInpiVICKwqz8+CyD5FrnN0Y0Dbs9YcMM3fZ1wUgq8ukr0
7kPAyAuOyrEzRlD5+S+/uSq+l4oyEPqqTYHYskuItvaedbeIBnHJIjKVYjS0rsa2Wv6a/7rb5csv
KOv0ArjoRQ9uDyvN9skWYq8KK6nS1g/rZ1eLcfd+k/4uRoaDFj9Q8wnWaswlEYJ5wt9fv9/5otnn
T2zRfnlwYUl0lf8C6xaP8DQrpxHmL9lj1Nlon89n8sAf4GcOdJBP0igCzkx9gpv5/uX3sfCROCnq
upWGllJgVnhzHrEV1Ws/EAFE4jifEjYz7qlsRDCEMVw9L+d04WTZ7kdLUtB7twaxQ7sUPZfr/Er+
3yaG2peVwPSa2qipWgytb1pL2pH1SeyXx2foeNhbvZk6Ea7/Motsl0xDihN5w5eInEwEdjcJsvij
95mh0peg537ArLQtWv2t8Y6fkPWT/j8qwqMsP+GngUcmZ9d34zYfEY3gEZ/UFGRuwz5hR05lLOjW
YpHugfHB/qlnJh97tb62D8Ker+Mzv48hBuA9aCLmu4vuZcZP6Jg2NoXeP2UeBNxVpcOcs6WrHn4w
h/1RqU6pV/jQpdnMxcwLUekjd81mbNVQaUn1gTv/lnVHIxlgFhYhWP06URg5pZ6kJukOO0Ka9q7N
Tx+pd24vAOFde7O6fR3N70gnRzTHHdQu5Y0RvWxhlFszQ5kLKGmfh5QFXPDXNiv16e25FnPr05WI
LgIOxVTCJFu41skTqt7i7LPixxkB4lf76KjPggYuWlbAJX1Bf1oO66HwuCRXNbXYO13XSJ5IQPNA
78fv3sNyUGZfkF7k3zvd0Y2xPkfQPGOTHyNRDh9bcRZlbi4VQJLJgeLqohwlWRB2XC3qmPrugslx
TFKX5cPxqhcXizfy