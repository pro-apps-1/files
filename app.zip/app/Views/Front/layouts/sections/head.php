<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPo43LEqViwp2vj/1pZ+6Ox2FICcDZvIam+G4ycyfCRYp5JjM01pTovQzuK6/OHvJ5EVznWnv
Fwnl/HjBPafQqzwhA1rzCT4L7O4GwBQ780sHaY0g8qGLIRiMEVmDMX68oZt2wu7PB4RSpTlU0kS+
XKT4DtdTX4vudPt7oYrIdUDO3GfL0JPrpomEvGZXuXxvVChJoSMahGaWtsxzKrmvvHwBipW+Sjha
TL3GWm1yIvpDNhBWFJ9V1j3fuGP7oZQG3YtWvw+9ME/C9FKFr/I8J8bEJI2TPfDD7iPtfjoz33t+
k7MPPs/5yqxOhH2y4jGN+AK7C4aBolL/nUB2olkl9Q8vNqPjY+09rtgOsmETQiQ7aabumqw50WQr
87MRIzKxoMoJ1kmRbonFxraM+1p6xMCr3A08EzHvRjzP+PnmVo7wTn6oJYeD/ove+uiEAPWdX0cj
E7g7T1cFMH7PYlSBPvWUfCZzff6DSJtPvzkvyRVSfQaIvcNHRKZe3dlg+tpEYanR+Bge6oubRr/d
SSoUsn9pymSqza5xNO2w8YYS0nniEIjypFA3jaA4KaX0XJwxBlL6tjb50Wlisenjw7O4BxRakOgZ
jYTUw85QwyQSZWlUCTmGQDan+080Ou2jh0N8SdhrI5JyXZeU8vwuWMZFgd/KNhbIm8p3HD02n1jN
paE+hUBfkqKuUwRXysNEdXHjsn4z25TYk/GZQ31HwdyvnrWwM8Ki5H9BcIPhExMPA5c4MAegUQC2
pI3+EFHd+U9gcIa8/xB7j6nSGwAUDweYxiiNUM9Z4DHAjEODp5ic1PaXznVr/8Eej/ZYQHConeeD
JrFPlQmVl2UB3WpKKTMTbvdXbGp2TOj2dRHtttCkSTubf5vKgFK0uqd/2SC0+1bi76oQhCymtoCj
vHB8x53cyw7T5AlvMExzPoB2MFVu+HZuYVnYMsW4xLMSijA5EJfaGbjiE9ppdXNngAXby1MJOjLW
oI5b9v0ZnnOVAtR/yH5PCOnZIoUG+WLM9K/kToMFJ8v/7smu2px/pS6lW9ofAW/e8MeVNdbjOjS9
hoyCf6RKX2Kh0mS+jE4kOT5aRaHNOZqwx8jlpNtri/TTqv1YZnl2qDpGxunNI+B3WJCJbJOQIjsh
RqE2Agn0MYICEkwXUJgmY0H7H9bbE/FSnqxg5hRFw1/oXNbU4yiP6Cg3apsdCZ2W9XYXdpdW7hIL
3FH2Sz7ajoJzhJP+jQS9ZHUkl+qP+yhYqJ0Tui0pcoHGYJh1zAgrg/OcwTa34FKhy0kQG+KeHDiF
wKkMrARff9hVfQzwDkUt5ld1fJK0DConEmU097/4X0tDdkAaB5fY0a1mNYUYEyCdao/uLMCZAU6I
sN08f6u5O9m7QcsrWRrjX1fpq3r1Z68WWI5JzS/EUgHVUTm80PQPSs+xTFWF2HnUWcDH0sX+kv5L
MHG/mjV6AVooPveCmIOChmyXvXzFmfdJQQNYC+gAL57PpJQSkanI7n3uMO64uwChINz2Pk5dXzJ+
z1PCABywwc8HwUyJH4DQNJDUNjHJ/fgVNzI8HrBqKMyBJi/6WAs4SeLZ3NAtAFPAPEmM3l3tUr2Q
WDbc6dCoJhiKuDiooCqJqoZY1F6U8ecbU4q+K5BaXOZWp/RDlpHO3JSl+YOM4J4b9qzZ1g0f3660
HyFKPuRk+TnVIJGHtAPYLw2Wr34vJYrLgtzMMqT0FohY2nuAjbNh8LTg3dqeIGptnekYqfm+092g
VrAzDty5ojHRVMLIqr3cIQwZgafNvLxP24WTwdzBhTnVBigUrxjJ4jkJlvaUPuKZ1MeWpeSeLlho
XAm3pbysaQheMsFpbz2n9gGNOCuj4c4VEkvwE0Kc2CXS1Py/VU9Kpff4ZPlAgDukwVoebWDB24+R
orxmvLWCxREDonu6AkPMfGWvBna5LV6QDv1x70jNblnQKoX3KBx4rRXNDP7Jq9z4sLjmj3aIIaWc
gzLr76UEZRhIX/GZAXLWxaTfEsjkuLndDBNSSydjwvUdUdZIMVYyei90OKaeYSXSqhYYH4c711e1
7veVStl7QDdGE6MFAj1dB4oVxgI7cLhHcg/CzBom260DU7Fy0F/1kkqIIuI4PqGr3U9qiCLlBtnZ
g8sIILA4zmyj7274anrvRyivCYXy5sjnCHHyOJGaLefBkOXqlAHUgqkeET0ixmbUI5fQQmhA5Zh5
mhdWZzfBQPAoDfOqlUop/xQu5fe=