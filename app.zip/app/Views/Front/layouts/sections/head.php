<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPr3+UI2VK488PZti0tq60OkpgAmJkF5m7UvjLWLQEhChQ6KNw7SG7Ikdv+idM+GYs10QoOJZ
psOfIoC9VVVWT8mkr8+dARggIuBOtqJfeHauA3wB/03+tKc1HzaS3smYMGMqxkeRsaPZKMJFRKD1
ly5GHRgJeHPCiwP/jeuGSPrkLJ9aL/7q+OTAK0YxqZHLQg6ssGp3wQepRo7bVW4PJf7Wb2/5Ej2D
X8F8WQDRR/d9uWSDG8MoCWFybwazMKXxa8flTV5UV3HNAgEvKMn0WDbY3c9FOorrFy7H0qabcglj
0z8uMF/Vp5WorL8bDR4+o0pW4ZbYz1tZT5BuMlTAGwGUBfeSHsEvGwFYs4SKtrHoc+rq9VjWlHEe
J8Y3foJBUKsviMhhMDAVMmRU87sZvu6/71KQtbrBbHVPE5334x31le8D1ZizwtuIejPhEUxd9sXu
8ftkQWJDojOeqcLV/omuCacGLD1XdCo3ZDCbFbV6Cf5REglhKG8J6T6QjGz+N5Ku1Tfwey/A5iq0
h9bfKqw0oXxITIccbuj8o4/uhZ7IA/jgXNdC1CBkqxX0YxreWyWqfuDMvKnz+pXd6llf7x49Cj1x
EEVOmMXSV5FyYvrfx8AvcEUyxAlngpxDt4B/TiBIB2KqcujrkeltnQjYus6c55wtTZ49Kblk622I
Pxgul+y1Lyn1st6zrlph+90QP0N+w37k77XjYz8bCZ7FzsAyadve5grFhjJM6AGqX+25MobZoBAJ
rn4z+WNqxM+InuzqFY1HvWKoftQRr7LfeO1XwkOeQ4BkPlxBl9Z6Ei7hKLMD2vxBBsLtOG8TZL5s
GLhoIc60zxlSTOF/Indjbzt0b1vEOsfWxX9h23N4Z4+avKAAQ1DLiGq8K8lHdRK6umKGrasNatmN
ttnqV+S2t6h28cGip8RtQbb5gdG6bDoeIE9VwWr3iGr+cSa7wMb9FaBpe9iSXSZjMVDe4wjCMePi
GpkEPDIRkm26sPIyXX6rCADDP1sHdQfsnHFAXjL9zm/k/GBOpNEIBUVUKcEltw6THs00xrirh4ol
NlevvC0bH0FrE5KXVcJOsZDN2eKgxyGkdf0OF+z+YYya95sPc7Easn7BGimwsMhM40TUGDEM5cTF
Lw6gR7xIATh2t5lHirFXusmA0l9Y8tT79rkizWg0pXHumLHLdtSjsK6AuvPWu212htZ5OtaboinY
PGINfHJvQgmpi/p1WnTYSlVc03ZnTcXpRxS02lKSFXFh88yPlwpFXBLJ5i69LzgBhqPkrJFvk66n
f+atW4KzzbQqqvHJgUEhCOVQ+tHw07SH/EDWXpSYwewGTs+guA4aCw2jUCfYTzOCyzlKtU/K5BNK
cCtHQirLTLl7EFGUYEXzAsQifWmBC3fKsGgXQrY9ibjo6e9C0CUhlw6o41ciE9VSiDIRKJd/2ZVA
Bu8hkuBia+ZH09XhulmzKgcT4i6RITchVkJcmNyv6NlQXjzBtyIfGWSBcTG5kxb/6bxAZhd8s/Gs
ga/CBTeS4ZxBhyh7J/6O7KBswpZU/LcLjxOzeiehavnzNk4Woz+R7TyWfSe1paTQeQ8H1b7RiHBH
R0f7KyV07zpz41Yb2cZ/T9zyL1oA8tLOdT8c+RZ7z/lMT2lSkZroIjr8dEFwYkeq1fv2v9qH/KZV
BUR20NLmAgtVb+ST559YbwI5zPq2ctiI05HlgUQbzbaAGh3itCLDHci3JtPoGfRDTdFn9fZTskTm
UVruz79q1jo4I/oAMI+ONa66e6bZYW9KA4lWQgM7eTrnXuXEqJUoXgqVe7MpNqZPWJc9Xvao0vIO
nM2Md2mrHGDexQ+pj2iZ0R3cBw4IkwFyeL2UY/BCLQdnl++Vhj/BFXuI/oVSgzDfmedhWys2mqfd
LH1BArUMJg0i81Gv6y/NdUK9eYbdVjEQUYYDMj8Gesg99+AMdX05cwOEkwTIJJNenc+BSr53GOzy
WTWxPStRrA4ZylsDSOpy1wT4McCvc+YdhJD67RXupCGsGhJoBFYVgKJOr5WUm6OgJl6nR9EDeLMn
muFB2ttF5y1l2jZbCWC4d5u+zuFGi630Gp94tMkhvojHXe9vAo6QDequV3Scukn23Yag/nCEdRUQ
g76jt9ANqxW6aZFjndSsQ6NABFAGJRYeiS1RpG==