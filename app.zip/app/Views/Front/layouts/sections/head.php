<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpDr2SaUvV7kvwcSwbN/0IqvPNzJpyp03R6ucw2s/yYmXlEiLpAUMILwS2B6khNgv9+AtepF
fj8tlVyiygIO+agHgdxvTsC5+skaxfFzUpC8+mixZWk/SgdrNsY2J8SJbUXP1rxPAdWFx7s3aJxR
CLWESzAF7fyZhvQWjT3Lsrv8ZIRpuHDLKSeLYEAzR1eL3zK+dnGgwZyvZKshrxOPyMRi2txLZoVe
CWFybWSkK8clXhlr5wBvixWaoIr3UReujclCz64dw5ckNa472QqPOhgG+xvjlG0nWZZtp8joPx81
YvaHFgnbf8k86b2aocPBWdd/MDL51fxP7s07nAlRIqm35XtMcx5hjdeiDSQcWT4p/1AzBhR8OwVA
VBTq3SSV1IqjaJ00m8OsMfNujtMGcqKnwVyvj1AZAIFFEinVYBxcxAZMJaJdXlRn9OVyndNUzkoZ
oFDJoZR1c+A5XmrL2NznUS22qbgjX6KZz2df+RW/Zs6N1fJkeyfFRn4G9/pbA8/4WyljRG8/7T+S
+HHksWGmYZqNL4ckrsHJCimpT9CZ8vpgnkINXO/j5hL+wLEI5JqvHuthBD23w3zYnJIKsINQKdbT
dVzWWW990P4pfIabi37lqgjJEZs2i+7tZ3+lqUlkle4vd3J/X/WQA9iMIgqNzO4ux+uoeX2r7n2c
vFYTfMJNDmhfUzfYNqivf09Z4D2UiRiuMvcnlm/oV8zD90HkkbzeurQLxeb0BxAAj6RdvtTF6smt
Uf39FkESCYQUKq4P0Xu2V9Lrq+QNnduClYEVtzaz1tPt9EYO5sVz8RPO8bhouRPrTGDbXxL7c85K
VWKvgZ1AZCrwk7I971RaouAR23zOaJLGWSU5fnykf0pFqy/gpYev7QfVt5PYR5DLBa2i+dDKNLeS
CFi9LMZdcZOoYecoonGwu0hIOO6lFcqRklzhWQaI0llinPeoumnOl15HtITd+/YXiABJ3w+QmuK8
QbQmRC1sGhokjxfnUXJw9KbjHKh3MLGFDewwET7N33xImF6LbgHt8oWJ3AzSmAlOs65RnR/qnWF3
RCVNi+z+8cKxUkscjdW5xxhmYYAO5Q8F9+0Ez/SWBvIiiDUelz6Q3nRNMbNlnXtSRJ4eaWrrdQ1O
PyXQFpNjCCRJrrzROamvt2+XQzW5KvOBDRV9+2I7roFmsyAApyioT+MVexmRfgoN+QSGx79qhaqS
Zu0NcvuCPMe1+NIigv5xtdkS17JsvwoQn88GAa8o/WcPan5Nl4YZwpTZpg5fI54oViGcYeSfyzG3
tuT5hW+GtvjhmUlsBeGYA7QS1tyawB1/X+KclO+QzcKINl34ScCc/ryLLBYManc/Us+2c6Ntn7lz
qNWRvk6txeWMSW9b0aNUbdfBeLuhrsHKY3Qs7lgDmMH0vdjZI6oEkLx2rBBQ885ZkDq8bo+q7rdY
7OV7COUA9L0BK+xBW05hgG7O6Lguwp2qKaAZDdovgg9JQUaudQG5pn2IJ+Fq/yTXmnlrbQALhiS9
FisY/f1KPeCT/kGNygd/3wjWQNVvuJHFhn+9xecBBr2i8I7gpXF9oFZQ9zdGKdmXNtwaN7YqZPTs
jdsZfG6q7Htio4Zac2xsdVP7AQt3OOv3zatBh23RLir3IjVLZin5iz6OFKP8ZuqVjwK3BGA6/E7x
LMDnfMUsSMLuDst/hgI5NgYCaQLCQoZW/kopp71pXIMeYeoVvFqHXgxC9b/4Ov22LAj//hl7ni03
yiEE7tZNhkRKwScDUOCYZtCu3VlFxe41lbFTNzZpcJasx2jYe/RyVsvvucYrSs0AQcUGSpNhDvuX
IMwjKYoCisOLjmGTseZMxKG5jrPKAxKkPkDvr+qBeD/kBeLBUNksMA8g2M4927YURYFV0c9usI7w
Xi8dDDXGH/S45ypZtX5cyBzWn2vxHlfTJze2RMb2Ly+bg5FqLNXqPFumjaoFIjisABSMKgc2l6JV
POXNPAfL/6rnjuAl3RyL9KLJxkALB953D4vDaqnLCeiz5RjMoFZFCu8UrpXSRJLFkAn4986BRke/
7etBTc34L1imnNLHFJLqIoOnqa76FkVqXaBgVB06T5B1pnErCBv7YAB7oGNIwbgF3oPnUAppdme3
vjHMgB3n+ofsY1n58jsAmGyW9ZIBAvpR9oWMfz6/B5iaYEfwVG60OHNL6ezXZpXcannkvnPPoU7o
hx39pxS=