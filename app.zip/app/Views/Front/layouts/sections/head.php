<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPwLIpNsP0pPoP8vONk7yA+lPSQ0u2fcnpisKY40mFjdqM4ZsrU3Gx6LzT0rT/dtHbw97XSzy
CVn5zwycm2yapcbd1W5/3vIl/5ZX5p8/ORRPwnZaGB+CQ7FjmDmHIgw6okYLkl1CGSYBryoCvi7m
3V7YfSK1BCH0ZFSl3Jh1GR8rqGgFuCIyu16t3c2s2/M3b4lFcLHqM6NxLh1ZKdHFeh11l+9w9H7O
bzQROCCcclOCFpKxxL4mfV07fQnyj1P4h1LQSrBQPWwbBFduLcJUEUtk4K2J96yA5kad+2nnwFz4
f15QPmIwApaHj2oTCNOfHjjLOzp4VDi8+6TUHLNiRNHQFrQhiu/fW3NkA9aS8wPJZ7RnBIibWSbe
r2L956qrXA2fwozsBhozrgutAOA9Ru0VZZfWq/uRERUycfeANm+HZX6pYu7ucvIIPEpm6hAmMDD1
DmN5lEbQlSKzJzutPNum6FPWQe4d18enCfpCDXGs9mHidUPVXKKrYRHoT92usLrKDtYdEqV+SzFQ
kV8REakBu1G6G7fABi2MAXU6dmRHX9zo6Yy9Qs8HRPildv/X4RCIbOi+WUWbVXIBbGGVal5x8I8Q
tOFjxcyr3X0TWzs6tqowpj1t6iedPA+VJL8PuYs68vi3G0VHOioMbxcdM2cZyF5Auh0jp8Kw+871
DnAbRhgwEGTNBCwsXOmBsYignsIwXB32E3VodfW2OTNmJ2kSkyqTAjWuIzYdGcLnM+HC1yMNVLqt
OadTvS+GutIH9ncehBloFh7K4ZehxnlDyewDZCOIGkcyDstlFdv31biGzMYl/arBZSU9ic3WnAnD
3fNkLLkk+PUJ08LQzzWoSUhyP9/nfeW7oYDrKdCCmGeZb4h52r3LnvboJ2/6GfI6Um+Y9aZtaAwo
jCNKt3iLd8B4CxYP0OAvWwhSNagQJUzKFJ/kcgdk544dRs+3x3txOCdSfZL3oP4k1Y5rWJzWcfbk
bu/UIelDEex6kwQMWc9MENux/+WIGMg3ftL3Mz149CFRHAiDnMXG3Vd60oOoUHTdsOtzHxbD4DhU
eQIMdu4WJuaSDuI+PUvcexW4OtdOzyViT96UKnhtgJqsQA3+IbnQutYwawnrQWJNRrk0rBNmoJV5
4yYzUgJvrdQka8WMX6HJIH0nlOMg3No9e2m36AX2OM1MTxBxKNIn2WRkojUJ2iGhLYnCwJBDuHQo
Qbx+jyVMXnPJm79xTISPIOoTtkfZQJFtNl1BNLX95scUPbEvuqh2M6zV3aHfM1w9bxYrL1Llq/vP
lE8Wizp9yNz+io/r3x1SU79lyYp5vf1abILNhGw/y7jTcHpFko8LrH+tCFHm85GIqWzTTQ5eCGU+
TBI+mHiWSWDJb903JBXIT1DayUTPKQuBS9DueEd+TyrEhCV7arKdPVclb9dM3ed9aDWXZHnBpAnD
V16GcjNeqelpow2SentyeZUpaLONq9vz5nUbskZUV4A3zrwVzbqH5dYxgksyimeRerFtTGQVuee4
6AIYGURs/IbnvSkSz0zW7E2AO6xKcu2AM7Bvd7Vp32+gPKx+nN/sJksoXALvCUp+f6PoWeNVPv/K
YVV5JK3urEQx90bSEU87TR6a/XzX8cSaaOaQueyXNdesVa2xfpH6t/zR0qoACGnaIkWKK0ErtBsa
p0skLJ6aEu4OavTHNTTuc6CRGubO7qMzHvgls3f12Vb6UP1yt0t8QnR01ncxjdWUdcBKQfcq5rao
RcXEdsm4X75vYM/41gk8mXI42WXHPFtuwuTEosghOEqZhJz6sko9e/1emmc2G4Cd16rF4QJSFm0T
MqpacuFwQIJUgQiczw2J+cE6dJNanSDTDJ5z0IawSRPGX6rvuna8r6ny7POvaDr05gy4SnsWrzCP
S8xBghszBXqLXm10PC5+jgxOIIiMs4Rf94XhH4+ZjMgssI3DoTXu4Si60CK8GtHoApBnypTbBdC3
Eqdcr+F8TXInmVf+SYYoozDVLOQ6UmYMiUgb9q/l8r3mwgIV+RyHRJsOKD5RgGb50pwTBGReZT9+
UZI0+kWDDd3AZwc1eYgUtfngYiYVmPKbEGpQ6dMvQ9G9W64fjJ8UR35chQ1evjvLT1nH4k/XWPG4
ZAzKMUJiZ85bRucQQrB8UNc6xDQXfaM/I/7w8Vk7oRdtJuMnEfDrQ+/be/uo4xbsoOdZVMycQqdS
QvGmfK4mkkeLdkjb25lQoiOBY+I1gE75XbK=