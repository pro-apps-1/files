<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPvLGFUs00uR2NOwepjzmXzcbCtmnUqnWXDfRYa1AbLTduXryQFL82ZM1iK9V8wAFeZOtEXTy
ZiPJoIjDOXjXECJwTp/BCwKRmlbbSxQyV90YEkMf6g/Z6yi4jjwvjdXrIQrblA0HJhE/37LcZ6Xh
DyUWrhr99fPSzl81IQ8ILBwfp4xD7VgAl/TK8IxycoPtW6I5wY2vFzY5LM+DiX9bWiC0XjJyYSu7
t0PFM9A2cvPFqZbKzucnhmHugBAKabcRY7c9Ja8UlJdPArgD9XhjxmGtTdtQPg1wDjR9pg4g0oqF
e5QvRFRf69j+wDrmSRvP5JuzdI5mCJUttO3ypnCE+eac7N9fbdd9r4Qf2l42pqmoQi+9nMSquXyl
D3eVdhqNllPPAzb+D3E/LPpjD33C4P4IiN1f4ZxDyomNvORkEH5pyyHqH9DHxsju/gKxwxErdLkq
8DDzZtHc8lMPO27gTyAdP8w08zRhDYCm600gb23eZZqYmHoGPSpTuoBSBf8eu98NsN4sGWtvOIf6
fC22bb5wkmXqQVe7KGNu1IW8wON7BD1WMo5WMCWBEQPa3iKcCS52RrUIcjRjJvi4KP/R6gtQF/po
IkxhDtduPD3QmbtR/H5Fmoeztg+rzhQCo2e86Gy4OxWOPTWp/o+uXa/fUh0WGQW3hksuHfJ+RQIW
4y5oC6GmRmf30epRduNnITVGRDJFoFv/M0b/LlnlVpqLJRbhdoImM+AGV94dnzFIRICC8BXLY8Hu
uRLdjVCLgVua7/ieVBzdjuqV9346CjDJLAwacO4L54/NWoPzwYwmCaAiJzEWEkDAvWIYKAWQ6T4O
pOAovhLskJENJQ+PG27KHqbodkqY2BZW+RMqab5lQr+D1XKwPQIUTGq8xCwvJAbllTApN+iZZGoz
lcTT6bCo7SPmV75riNG+7hbsgcLgw7gG3AJfQjOUcD/j1gqLLnqSRd9NusZOzgRclRDyz9KYrK9t
v0eufQMjvHSvf3HClORTDbsUViBuJ+Mfyi5AcoeBcl+BUMId4MJgXpO4Ts8tJOUPZZgra7RcxDXa
kTFgcHljrkVXbyfNnMZ4dZuE+036qWcnXd/IRxIEM2MBUWdgCPtZbZ4e5ajabi9x39+PsmugYcQp
+SAESaVcVp4PPkJgUB9pfaKzqB0idvSCoW1chvdmNbtjjxMAuXVoUGB/EKMMVLMdsXl2iqYXRYfo
biO4fo8A8bDWvBnCz9rx7HrmIA2E83XjUShXTwYX4y8mGqBqaOCfSBo4KHcp2Kkay2+ZymTGY6Ai
eKqG/x04IMH7sisNg1IFkVNB5NRJaLUaOE+Ayr7P8zofQTHrs2WL6nscih7Uu5Y0Y6i9rH31TI2T
r5WiDX9y1zG09YLCrvjvGk5SG7yuWvnt47//b3M0a10faQPdbJSKOFZoVViJTqkNfYSIClS137yZ
9WZvg6q4GgCxxCIeLdQfpgWUU5mMeah4tNj2Au+tU7iqMZswbJ2hCWMz+gseeCV7B/uYCbkMo//3
iwKbTsB2xut+Ta9l3Jqh9gO/26ebmxh12D0ZuN7E/kt2JRTgM7iUcg56XSeDcIL3eN3Fml48sKKd
8ti6QBpeTJeoMNyF7tCC0kv5KH1eYUzSsM9gCjnZfUZHa26snDpOtQBx2kXtGSqKKG1wUleKKRZ7
qyFyGTyIi/olNFyp7KqgXZHUCzPsDGhZ8EnkxsLFkFI6ehRiFblyxFZSzge6tfrMA8cxJQfZ5OCw
z5PllzLhl5KTf3FlbU/BZpttMF+43Rzva0m+skH4mnnIYhjZNpuUl3/yqa4BcQD7SOlp46O+5NW1
8HJzqOkUlLNRO9RPSOtzoUI5rjxfGoWmk6/1ycISCW8fyl8oYdezU76dGF0OF/3ZnyElL1pWD6dy
rS3lSD8vl6hUPfYv4OsNaVQm2UC0eYShThx+mGPzo/vCj2vfoBVy9nUzKuhqAoUhODtnAuaCq7JD
eFjvIkojAvk15TkzYtp0/ol5NHPG5WNYgTpJl/HRtnKz/peIZjAJeb8ImJ0+QN3/vpGHe48w6Pq/
GLTvxXWRucD2H8GwUp7lcfzSR+/XHZ54yNpxASYatCzn/VuFlG4gGzKDS+ESRI0UqR6xGU0ZEpw2
uu4tsZUFWJHehoNBFmd2oyEhLQouBxv5lC6RCMhT1yUTjDtXgfvQuvdwUdGp9KEzCuPVrGTprq8O
2r6cdcooGm2ea2BUc3SCozqpdvg9N+N+pwgCK73vf9tc6P3waY9YY++nc7Sij00xctJwl1NzQ5Ig
j8LEjSUFvtHSISeFZ4jDvNSWhLp7ph3dP3TlFwIBjqJ9gl2l2Pe7/Oni/xq2eHzlpDoZpxuDaY/L
HM2g9Mc57iK9GsArGjnHtkECC9On0bSsmK0sA+45xH6nquEg0ys12yFQkSAKIQ02s2vnXRIMvqqS
UKFBdzmtQMujd0CTL7hbR9gSVZrt87AVwd0GNFBv+tNFyku+IBb8PF97Syy2oL9r3wyq8rwXxn33
EtkYoor7S9GtUszeMouJDshWkr/BLOpM3xcrVsGAGNTYZdGoBDn4JoclLwRkJSwdL0nkTWCleoAG
U5Xe5lTLxUx4B4x9NPeNxqpG1ebc6YnKNdMMth0W00ibKOgLsSDf0qLLS9xjnyPZ9ra85FoExDGf
5iCmKOkk7vANJfFDqhMRhsLXUGefU+trEJii0K5w4CJhhShJQL2jkLUNvnKwffdysbHZ6QfUZbK6
Jb0QUh4dGUeFpAoW1ftnsRFd3SM3u2bCMP3TDqmTc8fdEvpCJacs7OUUjrsshgVa93yMkW8JxMcB
IMjLw8TB3dDqG50OHQAHxye96M+DBCEqGdRyu+aX6tM8zKllrsEnhc3c5uaB9HK1e+/rIVKrjRiC
Wqd0HNsdr2en7jkYGCJCjW==