<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPyjrbt5uvsj61Qi2Kccq2myujjqZhsIxPCDOH/tIx6UNeLp3JjSsyPQgzI/8ylFzHeZtDoKj
ACszsMz0/iU9HXNb2QK3tYjiNQtXzh6VA8PWM2uEjiiUdZ80Rh41V/7BXMqU7eKHg5T/bRx/uGuv
OMDmAl8Y/tUcDPtglSgDH2KcBOwlaKn4jooByIWq9Mt/6lXmnf6xsxKx3dpymUyg23s0uLt6NcyD
u7ths1FQxF629aSQQvgvLuthct+nnc5yvbrhLXyn6RP6XlHJ5iRjwexuwUoy0LNuRNoyDvqqvQXz
T6v90i+57y6oL7boCezDimfKfSORQXdjo31ZouVPQNhmvEw+cyILG+kfuNnbH60p9aqMOZsNn4+F
SMuz7jskUCIm5sFvIBRvDlz1LGSAUDOFpFM8BEC32Rc4Zic+uwTHEQYInskX+7ELsJVLQp7xOPmM
GilWdEmXlMY093DEJzxEjKX784XmFMPF0JI/Kf6DkusQDS+G+pGUpqF6/m97C6MF7sN/qUDJo5cB
+vsD5fChgb0B+mYxlR56M2NOThDjDRQzxRcryeV3d/bZ7TmVA36Mx6H5eYRIb+2pP8wBW/HI0tOo
vwXrY+GfW/Dq7zw6RVMIJRIuTXzQXr6x+UDscizICIiUijxLwNb4WiXsqisPLsehGyRBn7UQbzU8
zDtVclAfL4lGrMAyEcJHjiJrtbn4AAzcBXR5wnuFRFHsEXlME+NnqNT518uUtB1/Q48tguFqKo6D
gmlKQSslhsuA3La+Ng0eDt3/HKz1Xyezj4pJULiPobJ5LQh1D7MhejUgMantaan3BxEJU8jTavtv
5BNJzUjK65IcwpS/3s7ULATTUXnixSUfjTKVv0Q4QKgTmJu+P8YRlgv5S+WlgBiGZd6wlk2bM6E2
XcjZUpTDloh5WDW9AzkdEcsAcJlD/32JQfPmSYpEqxugEeTmUJX6Fe9KqaCzbEjteOBWSQzNpagl
k67jmJKRIgDJ5jQSnidCXZyay+EvSRt4LWw2XjDJ3f6BZVxBbh+sTvBr8vUkyOvc44NWie3tdr4V
q7NFq5vLcBGLFN1tq9RvjZTc8YC7kY0gnq+LcotKlT8LNlMeEg3j7+cwfYKFxT0zDYhXQeEspXn2
JKOiAli9fMQQqq5Zu0Ci4aEM8/KU7kbO3rtj9Wf7g4rL82gYs/pEmpvxoSu5NkJyJhgD2FoFpSUp
/ZKX6Z8nVFQcEn3LmMncJJXktc/vAKIV+qWp530AkuIH+irzn/6iTIYwdKitpodYdlta+di1hKzc
sq+HEUNrQDLTbFLq+53OhKLC2d4PaARxlvULT1SmmsVszlHfOa2VgmC9fpr7hizUxlzhAF/dh4es
IihtalhLL26fiIUQrzoOkxEe52K0ETd4clzuy28Qp0z7n03RJPCdYTtVPctzLMyu5hIEIB5wU9RT
+ILc+P+9Bg1RBsC3YSBjfAkDwRZCrvaiTgB34rPQBsiVLG7YTnNnifHwK08TOgicwv597+XduVCS
usr2vxwG6ORPxv4KCbCRYdjxcd7/WJRLI3lUYLkppSUTUrnGJ01S8qOP/acl/EHz/YXX9IB7Q6sO
K5gxWaDFzusdS8aVqNNz+D8VOSa+umR0nygtLAzaYbAx/zU1JCIqaxDdEkEcD6TJnREGJAL2X1/g
Npe9k2d/GbVEl2mpzwBa+L/GzXWk7X9IyDpAtEtddOw2SO6lOoSwKbQPMuJE/aUPlPXpSl7+5Xba
MG1n3CHlpgsI7ZFcZ/mNxg2NU2NUEHGVJJ6nwcJ1k0fs5Ep9TR/VeL3ZKojxfwOqxTihBjSvLC8d
k6VYkFmEKjBJiQkHM1Bpj7g25JAGtuN4unEakTGeTO3btsVptWfLKn4nPUieP8/BLElkTVaibAB4
9wR3ysubhvwvoqn8HoDhO/DwzObM0rhbBh7kDBYLcsYdNCuuauav6g32oywa9XS98YD/nUiDRAUt
TTU+M4vqz6Q0T9jQWELjW/9wbHKjqjrlvGGkVJIGRZCmBfZmhvAcJWxdBAEsWOZnthfNIDZa039Q
9RssTkBKPLd6tbIGZzpqP8MnLKt5GtBWU1nUr39e+aIIrYeOWY0AGO4zHXgrMCdgJ938L56bxw3W
kA/cXq4JWgJApCfyVyHMdnPzmS6aRt7E+Q5LJpCaMtx8ai1OfCyoVVwowW/tboTr5Jwf1q+VvAgI
amoBvvoFqAtYyTQzvoEjaL95GcGIiJ9UUomSXu1hgNCISUBPMNbDVbit2T/sovjpCaHdl1pY+MQh
dnJs2pBsYmkqGjWsgrsxPZsSnCptT2II8AI1IZd8JPaMR/O1tkQf2LS7q7+olUqkk6LUpQJ6Pm6M
onA0cTQGXkuzcRPDYWAhoePBpAZmslRjOVKQnkGtIQv+SWMJ46dkLvfveDtGa091nuCKvskHppX7
pGOoCvG8hLRfPemJqpAqjz43erR+QvY4lFuHKdsQwJ2jZ1eWzQZPesEiesljc9JortudDPX33PHT
VgY4r09xOH2kkLO3TqwDgm9bzjiMWJvlbv8Yo8cUdQke5tEsxQF2WEPFp8AVLavD5WVMa1GlL6dR
/NNzQ1axj/G+MUB+5tvNEt/TOabNmIBtZwy+4cUGPg+Fu2I9cpOrHtzya63Ebn/YPMzl4roUGLAV
gXH+6+obBNpbBLyky3BjA7zybJu0zxrIy1uRWa8Jeu1RXdwMWYaQJQE7qgcJBR/BJkmWFVVBBR46
urix/oZb0cueQyiRhD6UiDVPktFysx2MQm4wSelijq2oRzzeebIvR1nO7iAoO8yjpB2j5rBxX6qN
C6tvB9SwP/lYRk5mSoBqz9HUA2Y+h8/scn/kEym+n+sJdCJffuHk3zeYWfp7RLdZb6rpRObu28cO
87iZYD+k4kE69m==