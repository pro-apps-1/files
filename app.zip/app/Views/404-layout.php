<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPpR0nASBS3s8qXvHX2q91ELUz22wD0j36AYue4QUOzoDlDgadsRZvplbg4Q2MdJ7SXlIRIZR
Oa1k90zdt0nzKuDW/d+EgZbh0Yiqt/8OL/QtEQkrfdEqWrB2LjkgtArC02r1yqq6igq5LSkXtnPq
HCjE+rn9stPRITb1qcfrTRNEhBwLViuRVqGUKMgFQX4Y2JL0kBo+a694ti6n99CD/lELO11PELU8
+MM1tpLhfWtZLeZ+sCcHJAaWj9axQPYzwxnyGFk7vgmggRGTeFMWIDFai8HfY+9QqvOwjVbTbVtI
F8SY/mtrZFiOkYG+1Set43DYbUQsU6+l+yPqxZvkfhF0BD6Zi+vn2900HM243R2GpA0PmZaTrGYv
7fxftHEYPIOhKri8mHyf6rZiRm2P8oYjroWJCXNvP1lz5cDQdNEbMwXv3RSsugLRKqf4d7ojysC0
4WfstcHwmeMhnCJl9S/b27CIIhBgjZBfL6VBAExEjDNMToMPzDjq1zQF7H0vh6waVv5h77KHJjOp
m1YAzJXHhzTcOtlgxgh2wjRdnOkoL1uwf4muqYLrtupxOiqODvZ1+W74ujK/4TurINIZnz+JRK0q
rEjP0S7Nh8pgO3TIDOM8Njv+rhWU1quHTlNIq1idiXOvlOLA2v/8Kq7StWqWAdAFhAk+weRWFJQ/
4eBhGRbXwn4z+7IKi/DttwYKpiwiYG/Qd9DqSK+EsHQybjiWikRNCklaamkMyAGEfFI9G8eVqJ/K
MuavPGxJn1O2EGcqXtFEeGY/+MHuhoC17lzqLTpzqYPuurn7BKcdHg0LumdlFf8FAv13aWm3ESHG
S2zd2znIpi+Lq1sb/4KJ1e30DqcixQi5PkixTabvpFw8Vq3z1CwtmDKwsObloZ3K7aGChj2XKDyW
s67znWj8Ud8ff2MegOglILBQLBxrJexapDxj7ta+C+s3hzVQYunadru7lW+0fICIM/5i6cA56BLx
vZY+nA9dajFLQlzh1MAh/s7+AZfVVVANcmA/nWUFAYsd1EBWU1R6+LQrs1wvaSCM2ir0OEo+9H3w
wapKx3eLpMD2uIbKCtZpGYetyd24748rAw15SZbDcl0r58lctaGeoqEsZuNO9g69FQITCzLXEqbB
hqIS0XovvsdaDD9EPFAUkrYI3UtOsTDKSjyJgok2xORkpNPs8UUT2biiOmE/YKVUe5YUgeLerGnE
q9t1U1zoIRgWFXX/P5JoryC2ZXLGyLUDy5kDj5iS3/goBRPXBkceIKUZPDWDDDYU8sCSFZdbSjdw
b0YwOO2pDw8vzHwr+UVvPbCwcUvQMsS2/WTNfjNezBkTRgIpY+GhTYu8JpFMeyWZE/IGrLs030DO
oKXsON4GfnZl/87Xy7m1q7FNwZYTYBs5RCHI81i/qNMgW24HNowXYRmrUNzFr8ZqEpT2uPx2P9km
iaWEyl8mLhVIy09QxqJ2QmAUPVZiioS+OFxunGTLanMOICWtZ7tGi/wHEC+Bcdg8OlJRYc78GZsh
y0BZj8JfrnqKAmUFr/IfjqLl90udTUw7DtAzbt35cfp7ChXw4vCgtBBiOMOSU9dnN61/b3bQq5gw
kEBeTpZUI8xWiaMiIpXVpKuL5qym9rPKPwy6KWpBganoiBqjNhLCXMRbx1UBiQKxaThync3svBds
TytBYWVIhadalU3vE1Z/Tu5+0Najsl3x8MC7y1WYhUZ3guGTGm54RUaXyNbermjL1rezsECLoSjG
VGjHBAF4xSPxtpch+nZCX6nBCDMRO7X/r1DfLhRJMl/t24QlfbVNtDmiTo1rCX6IfkeuSO2Wj/4b
IE4W6Bzqle/tL9YmAPVGMqRGhlXUOSiZZIqxzb3UTgIChlxpGDoHbwwvBnTqOqoPgQok7+z/P79y
P8VKko2/cE4EGZ8oSguL093GBj1dNeCXsSVIOq6O/hsu6Vn4G2y8hR0VWkAXKS9JLhuni9igB6Tz
vWawy6baNU46SFxGAt9XPcZbFrcFCJ9vaEvVROKAM2GeLBYhZ1k9OP2ZA/y9WuOoiLILniglwxI2
k9nnZn0zVN4N1WUFPFvMd1HrOcoD9q2kNW4NDsk+JMjJYaXVtdGFS5/9DOtEKnKtyiEWapd0nwEU
vzHiWi4uZTWov86Nv05F8X8LCAUy75ANa+DssUJYEK/505o1bVrGJmEPXmdZiuDMKSG/xPiaR6uA
IApun9SvhXZOiNL8CqFemQdm57Py7nXqE4CJUvoW2PboH6cII7T06x0HaYAVMpXCVSkyxaPE8aIf
jOTE9K6IG3rT6V/6HCeWerBwLOzwVuzZdc1cGhZi/IDKqFqvSQnhIPLSQ2S7Pc8AMGUVKGx+uIic
ExZV0BiAQ7/R+L6A8I9L/xpTJFXn0DMOwJQH5p159KuBygbf3TvDaDs3JB26Y8fo4WXxWuzXkIvM
M+s8jxecLgP0uIxnW/luwup/ECIhcRf+qItPSk/RbYyIwt7w34CwmapK7tXkZiOAdHwK7BhN2Mr7
TDyXi6PJqD3xjTbzve4g09xX7Fx2ges+cKU0w9zkjeKzrR+LSL6bYbnDimr0i5a0SnD339cROX67
qFD6XRvvayGWRVOljhFyH8LtZad7gOdTQ4nYNOMaOJyBIaIFESDkq3P+UJROrhRy4KVd+0FcTrhl
f/nmaHJpd4Gff1kfFi9GwBi2+L8DTqiMD1Pt0QaSiqVJzqce+0UOQmnxtGAj5sEsf84p4qc2B0Hd
631pcqRL30L/siKz2R0310e6VOKllLV+iVgMa4an405COcz9qpjarjqUrzHTaDOTMzIQyk0UJx23
bqxCd7tHQvAhN/pfyPc/0mOtOgfTvUPE7dQfq8wLG9BfxpTeW2RfLdXRuc6rIONAg+wyEjN2fZKD
SUarNTh79kOw9W/82YU4iJ+1Yb7MC1qfVD+8MIgrFiQU6ThEzmBXKO9GRUM7sXgy1zX0Sm==