<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPotOdqgXc6Hjl0OAQO78+GTXhvKxRccLpVvGcEKK376TMiJxRvIdllMa4PhGv8mAwgq6mNOi
4/LtCRlzI6dYIjIQW77Px8mkwhakX7aOn7LkZ6FdKIGfSVDTNvSIb8AIJLfE9+BziK4/wcVpHJdw
P8sAzYriQCOIZAHqGrlrHP4ded8qaxBfWwoBmcPyRL9P2IlFOA7CWskozO14RU0XqzUVrn/UaJEu
++F4+H6zuG4mj8WX3ZE6XvPFOvoLL/0cg03Lzw8HV8PEId63IeTpZQKxUe0KFsnbgv4WZHze5cdI
hUFDxbd/PFAZ/366txByonE8qyedABVrUy0TnlnJQ+9eoVN0Q1RVLaZ4hTRLDweXLRtj/sApATOR
O7ujbT9cEdJQm1z0J/kOk2EQ2ACEkS33mqUNu7rjPnb3Mg1ZdmHvJmtEEToU29TveEY8GYVgn3xG
oQT0vGfbyHxvczezu1FEtdWK4c8krmGa9cMIBuA8gkSGaw/CpOg/abs8WsjEAN3lquw2TPm7kfS1
Tfan+xJCbujh3ivqRlAxhbUDy2qPBjBwMn0LjbUJrVfE03SBnMXFP8lFXM6etBofNb7Yk/vxtRxw
dEfRR1vlVbaQ8s5AT18voXrBXp5CmvIb1a+ZynWR/LZgQqQ7J+dGY2Wx/tzDPWcW0EFzfPqKqoDK
767tjbbX4GSJ2pI85QRLxeApWwc7YhSwIZyC9GsMfRyuULbQ3OIbu2IR2C4WJhCbYueEk3PKtcek
kk1yyxu5BCRokQGYWz9uccoitrDgkvUcqis4zwSQ+i6Xr43zot9xeeLaFHtKPVKSAzxQM4SXccTe
g/JyMCtPjfRkNSODtuF+Bh+WGleXhlohwFOmZejD14qIgLfNKxmTukr671y/dNxo8WaUbHjn8Iba
ydfDhX2tybbUymM4nJH0P6+qdDeVj0PSvex4K5eH8hPAV5TEcZkTjA9IBmdKZ8BJIZC3cR6+noKk
jBXPxplwkM1T//TbMUnwLLsbvNUz4g5B70uEo5oDODJNf+N3CpsUJFqM83IIs1ntWuzj6LmZPlo3
rEYDf0yAO2u6dn5ryUaYRxOukg/BI89FvOtUFICh+Bw+pTD3LAFAITc9IPJP/ZLfXquDTnGD4Q+Z
iN87bnXM90QT4D22v/cVg2sb02nAMQ7T1W45CRiD/HeXaMq5DKKFyhWctYpBy/yffSRU0jwnSYad
BSTap9hwBJD19HVwbtL3XafZZlL5fIn5JtBZeUig9qaCqhV8vGDrCMR49rP5Ku7vDdk+q82eNpPR
USZyY+VWiOKmTx9Ns7r4y0/qK7npoouhrYcFfpk6sevouTI1e6HIGUBb3ASTDctYKonixjwklIhy
4bDC4vfVNWMYC9RsDPtr8I/IRhoT3cAj/fxD3aqLnSoOdniCmK9zYaoPz8AOYIPxeCFtbmRLm1mF
neDh9InyOeJWCQowOpllOVjscqIdAG+ROFpSXmZ32xdXBLZ49x917tmOql7ADbvijU2OjXzRVXZl
nCdlRth+biQxva2M1B1EXd+Uxvo4kenjkWJ2bnZupeqGkhmfnvH66r899UdyYuBuIc77eMT+YFrz
k/oDQD9fX/ZCnuzB9GnL0HDpUV48vrksLr56nQeIOT9GE7E8+TBQWCMJCaLzXwYfZTao049bRInw
8cF6dv6nmawLD9iqLqeFnDQ8Z6PXuLewkzNfPuQp1hnUubBGLlAzG1R/1CCPpc9mwp4+xN2EJ0Q1
ClLMZLGkswAW2F04L+w5jlHwMvOuLoxE94UapasaU9S9ObUukIajgEQzeFhnKKc3Q5lMTXg+8edS
sCBpHMU/px2si6oJVVDCNgi43dFrDh4pfcq23zgmT/SF6D7UuNcTyF99cDrJHAaKAbsEnSMXCN98
3jmn6b/DNad2UsrSQW/IKpgDVNNlTYMV34EZD2DeHEY2dv9wApWHlUFAYbMUlJNR64+M1DO7g0n6
hBkG5m6LF/uZSbp87K8nO3trCB/7jkLNYISx65FayFIdg6B+YSGirGuO/KphgCi460u+ogzfKbNp
nf3xmp+ttI5PW9ZdH46YTeHdN0jpZNEOSh1aT+uS/9mqKDeoMQFZrfKA9ptgfKexLRFkCO3m2V7b
1Jxh0KJ9fdhK5sdC9u1b0Uw/mMA+KriNBMK7u8ODX9tAACdQIyxiAiOAfVoqp1pLZKIR6ikrhKL6
clbRVJPT0a/YOYmo3guJLLtVKadXtESgb+G8wQ6zjuzzQCZg+7I/0QqFYl95NsCkjBj9YjHQsJAU
trC5gh7jAFKTnDuwy6hRMkyZVG4RDyLxqt1vEZt5RCKSPNlHFKcKwGwQd4gbekLny0l8G3dwspdR
OhFCEuVqUSYy7siKd2JrcLZw/ZfZ17ynlahfsFMZn93hzL6N+bfQwMtd2iEhKR6mntVe1vk3v9J2
rn4Oyujo4cMxLRhK8vJ6Hr3dqjCTemsd6IcxLtgVlNpAgn0UMl0klfyvh9OdZcpFZZadXrpeuRxr
c1Dn3j3H8fHHrRk9xOeV/nWMcrWVTR0L6HzGQh04rG8FFINALLYY0FFgieui1qea8rDqYcQ0DhTH
wJtJX1ubvv9luWde2zUY8SUxGTMSA2hDhvCnifG8uxiE42Lezer5q5rtMyp6qyqXRURPEoydtZQz
z/F8Y0u3LQjeKTHMWTWggWlT9WGo6in5FzDzWpvY6zoAUGKLCI5yc4aX5RFWg/BGscZurUct8Ath
OxIrlrmUmMsrAYVVS6MlNvToa2CdeQrk77gU/v8ckVI9Rr08vsvsmS6lhcO4MrKg0xnI4IuGoKgm
vTcYfqPKmmm+PrB0G1j0zyrpfEL3iD5X8I5R9Sz8Os9tVlrgca8gUC7URicKvtjCOaeCjlGg4Bcl
MWYe8nWPp+XUkKfA0l7DebHy/MCbdh2hxCuwwU0SC4RvfLPn0yd0d8E7uAuIJserq+n9M3f1qrWH
Do8i4YmzgZRMrR6/4UMWfG==