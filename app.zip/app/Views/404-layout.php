<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPsTeXDUgw7mOixOHz4X+Fx1abCSw2jlhGA2uvVSFoEewMSlgwPRuiYtyucn9ErWK5EuWaPQW
5OqEMz44r7y5xWsS/FFlcAtmcDpmAIoKLXH8znNw/VsNWXNPBKpV/8QxPLBix6XuJKo4oiruiFG7
UfTLxXhh/TW0Nk8HU0uDOIK7xg57Akxy3b4Pqa3YH8aPwsqIOJ6mpoqQlOyl3hc5kjw5Nvl8IlRL
eb/wg0lIrSh8ElJiXMDt/ekyN0LUg0OrtSmHq6Wd/76Lpb7MaO8rknKwRtPlPgwkwIV3lX2alj3Q
Z3fp/rGIJUnYJtgxYR+r9zUTfCdXm/JNGC5qZJcIhHshbjExqu5v8xZZjlpO6bzbA3sRjlwoisja
slvWCw2Pr7nVucvgC5ogxzwzgKzsCPsOwGigRw7mOQ4FOFQQ69ND9Ca+EzIeaP1IouDMk46mwWTw
lfveKCo3OJ9MXqkOSCDqGYaVj2Rp0orjszbgbA++3ELQQ4dVbdb/UeIxfwVlzYI7LLU9+DFyC/Dq
nutexlCZt9Yd+DRKQsLLz9S+9kt80UTLHN3sT+o8rKQfGtUKRMKfL1ajkyLFUEvEj7VdJMXRxVYN
K+kTl57ab+uQtaeVsBHOe2ag+ucZCrsckl/PdEPESoaBoPPJ6xi/C7u68iI9KnuQn0sdbi9TK7hl
3xUYDS9ZpXXCycWTaNyV0ysUQmCVVXCIjE/h6TIkjNb93awjU6DUf/6l2roeAVmJz/4O+uF18bTg
dpedTvnOnyClx8y3NQOOsG6KIdHkeNyGM5hx+q8svbsPgyYDN+XDSSBK6wf/hWtHI8HIUnKcE6Zq
fuRwhv8nkyuFPHH1FoY7qAs0X9a+JVMLz3CB+DI2J65WT/AZDRMYLmeen/qjj/lH5qYENcpa6CDf
OxLtiSRGXDQOxa9wH9Tl2eR0S0zMa4KZS6muaB/hICJx4HpbhHck/NgXg/OEUlUgCoXuz6H420pn
2vdde+1sAnj2GcmO5xyx0K2FipjkmR+vQ/T2OFT1pSrfeAgQb1eh3PEXqs00aVjMRHKc0qNW+Zji
CYB8uLJ2ykP0Gu4nk6SrYV3e+29SePqlWL09laQm2tBNlJR10H5uY0cyRWy1mdbHY8heTCKjMkFC
/lWxlAFXfRDkyC+ymPyv/4WvHlYyeQiqZn+Elb00VoHsLmKLDbz91JIzR97lsinOThSuDwpIVOvf
akPs73U8X5gQnOaNd2sI0nsgdSljWBaL7x70bm7ibP84Ba4YTioylkbp48D5qczEUuStfyMyXZeN
bNbBtMoD+PVAmjwaB3MJxY7MJsVwMkkgkBM/8ujPhxhslKaaTjUdGo4gRhVyVy0hTt6cJvAwMVrk
J12B9yXEryFCdTzWLFvZaedl/kbHfqFH88RIReb+nc0YDsu1TqJ5S4eFy0BWKJHuKli2+SRywryl
eIa+dnvXhCdLHGD4FIBP+A7myM2Kep5Jcrtu6SnOA7FeKUwj7r11JwINBXa6sarSP2NDXNB3Yvbo
XoUMXPcKo8b+CC4n0N27v5HlnzvrzSAhRmqme1D+r5AvAsJU7dJqL7wtFypPNKnthFxDMuT0MpE0
axLSZh5JMZ4fzIwILQQCe4EA80pJo37Tiy6viznKPiydI2WpT1LtPyoSrMhUVX4Wp9qpk9rpd9OD
OlNwU+XkMLLgb2e51Ssc7SJmSZI5Zm3/bfQ0ircffVkj9CcIt0PBuQJn3ofdvyv3p5mYdTdIpHof
tUjtRvXDD3VVEvHnRJX3/E2H8bvMIK/Wf0LDXogHDabeWNgju5bxISdZl18cqwaD/LjJ82PSLYNC
vh1d0goxvNwIYR4z5iWvaDneZY44yb5QnrM554zN8T1zvl6nRtpK5vlfCScLTv9XlsQLAoyP+ROa
vkoOdaRdftu/iL4uEmxl3LGLsrduTBld4i+JWQ+1TgIN1cWWIKH53tQ28mC2aNUfKB0pOtJKw/W4
K7IHIOf/2t0+TDRXLf7aATml59yhr2e4x9gh4qvRYeQuf+1GI9tIlr9iL/1bMJWCjndbVFz5JeOY
V4Ie05zV2Ugf7qaYXEH2vuyWZd0qMev/9bjNj5bxs982zMluPmKtAu1XwW/X7UBpGajvp4VPtEwT
oig4HKHyDV9nqrkPj2fD+Y0JWaM/GwDEvXTsEmp54nWnnZJI8SefJNXpOKTcEnS4sXnpY4sJpjYt
CAAGg1GBXCELGcs5sHDHFO3cfCajeuGqHT6ji84U3mnl91srDYU+eYIZVhQ7QtDzIcGcgF8s9Tfo
KXjmbuIolNU6uN9dQ21OWwtClTU5akS7gE++7lpxJLRyrESCX95nID2hItuHm6vDgLA8a9zNJjuN
am5I6WNKmVRd6wlERn1q25lvTN0u4evP/qqZ74ffD8hDsgGZo3vgK4pcKGk958p7jfJr+Tk3pkR9
KPz/1XUGUVvExTbIifrOB1aOwm83P6hbAN3gKGURb1dnsUkdqsEQ8f5h2SZmciZP7/5bIK9Sg8Cb
d1uFsgmbTEpK1L5KkYsuOHX5ltYlOFtj9+LSLGFBdKmg2dA2XdNz7zwlqJesb+IYqmyjZfUJxn8d
jMP0Jq58kTbiAhWuU/Hfyju+wBWriZFz4TMjP9S8Nd2H0POR3ILtAHBRH06XE80L0BNwo/Qm1HLn
75vCeyAykB9YVnWE3+hTjaWlGcWgSmYXb3yfXAAgzQgY1p59cvarMz3ZheFI2Jkt8r3wzMvqG1vR
L5/pB5TX/B1Twl89ooBo8grPINtC1QyVfM1XjtjYu5c4G7suOa+BlIibYGfOFMsZrFfvD1IGl2oJ
vx6KaJloHOuVc7HqiK1OjmnR7HzkRH4KyvaMW7EptLBny/brduXU9jrY7hAer6+XTdQ5f4cDdTMp
rBqokW==