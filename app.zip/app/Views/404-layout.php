<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqDvKCNT+wZgcAV5vk1mCKDPCfT1wyVgwggugqJMH3tNfIwYmdCEcZNG2KpWe1cm1ZWEt5i7
qZu0WyMqajEdNDhXdc1s+l3l6/biUbWU4qj8rXrITnE3kz/GF/s2ykIpXV1ttcDhXpwDhh6aGV3g
IqzLOelSyxwqPW2pFKIPQZ1gcgL1fpePTfZVd6zL1OLv4HDAw4H9EksbvgOpY2bE3XhEToX8vrwk
XejgWdKBcATsGZtn2J90IoJGQirLaWYEWtaUBFA8EKV1kGqKsfbxMrk61VDdmdSu9lNP9NsgFXxt
ywKV/r2Z4UF+niykz+Bzs12Y0Tnu8yA8Bk7yZtKQAgyoY8yYrmGRiEikjALWYUx71QQrCdv4AnlN
zuhgFnhf1zSE5tmzSNaqrfwzAhl/XDc+WWnTfKE0Eu0exkqTc1PN5pSbmT14gCdA5LytAh5wNCr/
R4hwmMGoj+uu4U/NQAxgoUEguc6uChdfjV6/Uu56MoPup26uNzgwP5chsgwJaVEJ8LG8BskxDJKW
2g95g5naMRk73yHYo3s6UrvYMu2Of+WkZtxefIwi9R+N3PSNi2+34YXxCg+c3svysuFDgncw+8zD
UIGdmLTeHEMqFtz1kq4mdwfWYtydjEYe3yYJx6Hge6F/eI8TciRqezHXpbg+xA9p1Ggq1odlE2xP
s8P3ijoN/zQU75U8cK3bo1sv9HAv4uZU0kLpSUqGiXr6CvNWJIzu1QUy4PIYWI+ihGOI7ePdnMYD
WAMSGBvQA6FtuiWQ7b9ktWjJg+nqYrzhIsbI8XU+BwGj2gH1eZ0R4DAyrgoUw/+Rp8/Rm+MpywhO
ZfsXdFa8izaBslDV/GGT6D9xqbq7kfXpfL80NEjEmaId9plFR5YQA43wHjnuHMIz56veO2//xOgZ
/uIBrY1smba641nPjp3D1r1mpcgIzWWX7AgKfRUHpJdZ+evyMLA4yw/x7Z42pn0p3Fg/YR2xGnwT
RG/FMH7tT3uHsx89+/sxrQ+efK9ZKvauAqrXoLSXhJDaZz4Uk9uYPLmME9hPP3bEfRt8nsULdIwF
YbCedkfOowamojkVLt1gCv92maANyiyM136CJJ81CjZs3aWSv5hkU/wBhODi9uji0vzWij9Zt4OB
9l7Gz3rj6CIWtIkYb7yeYkAocUGu5v53kQpkro+MyVVygemMdzu9V0AUjUb2v7CAR7sO16AJ4/yn
HgCl9kvqeXSNQwYxlve8YY43iZl3zyRYtwehkCj1bXXVnp7u/Wx47xALCnImgB/ebazn2x3FHFl9
J2lw3vhb+DfhJlSpmnAhKIf3g2cYB0pR9YHBKL/wqQ5ZYDfkWeOK/wHMl4GYO3rQzAz053eJfVfC
aovumdsUis4SLJ2bQfk4SK3KVmNwhXYlUXZQq2B27m5YOhZFR8PNHeT+Ick7+jH7XAgcQYO3G8Xu
pi2FfsLQtTspivOey4R1OkmdfQxZ2QLoCgHMLMpv21ALyubqR7/wCi5DBczfRHSXii5pzl/lzelm
3F6dRzGXU8VIBrAowaasqs9n3U9fDvUc63B/vnI3lHPOkN9VVX5558DjQASsEb9HNhaE0XyQPFKd
osZZat3cYgV16ZPOLnlSrzYh7v8Q9cpErsbGlM8xVjC1A0OL/c7WWS4nCJL6Ic0RCBBrcE2UgzNB
jYVbDBjwoxxm4mQUpnHaHhtLFG/7p6bEP+ETKYMwvSc5JLKDJQNee9E6PHjSDjjWakS2IFjoL3cW
mbwV09GwR9FraeCrnEHor3F2Jql2qvJ0u1FKq+su1Ycyi3wu4LRDgTx2W5DwR1Rt851yrP/D+rn6
zqORv9pTiPUO2pQHkdrE/KDAukC5FfSqRm7Ld7jzPaJboGE/PqGIKkyG3xgE6DAgpy4Ad05XwW26
op9Wh3b/gLkp2kusfYLVUzvPbVK+hpZIDwDDBr8xPZCWVJrjb7gO6bhKaA9f+oct8EdRqqMuXBTb
a/QZsuQPxf8OJCStf5tL3tHTdlmTMfuD+3w4n+Pf3BOq040nZQ3QQvLt90ajZQY3+hLldjE4B3lr
5jR1elfAUWE4fiPEsr59vKO1G32PZxgqyYNaMoLd1Qm2gQBFdHb7M4wT3tcZseaCLnHtIThkr0RS
J4pSrlrPeUHPZeSTathvWq4Bwbw7aHwAbxKtGa/8jeQV/QbOdGBoCQcedMAIBfvUCOp78VDOXL5a
++vi2EmKa71CVcXM6eqH2Vs3ek01MdU/XVgADaLi9eUICGRoRYdVSYJrZOz5xj1zokIhricxwnz5
ZsFODUefYAo2jo9K2HydkyFv7CwffvGSvTOOsy6VUdeuCmGj0thRxADE+unub7JlqYwQVherNtWF
OpULMdZsVgH3l5al9akCVZKfpB9YasODaeaprp1740vXIsOcKLiJuI+mWn8mbw01xIm1Ad7v9z7/
C7XM1AsM6d16dZFZ/xAU3VXUYQ74UQhf2Hk4q4FGD4RkdnmYZ4mVc5tAAD7+cMOhfgDXbxA2dnz+
YXoMsewrSP46sJssIG+WkygSI1ySgtaFEAQJiC1WBZ3n6BnWe00Rrbe/6EImGP7irhcyCBvZSHGd
wTliFKw0nV7LP3B6uIoG5s2l/OnTuz6T61jpWnvsQ2gp6BnWZkZsTzfjKyFgm033p9HVmud66Xw5
+XWAMSA1rCN7iCoioX7OPpcwmRpu/yZLyIJT8hIQSNiJ4AE1Csi0uPoc/01MVjBTt27C3M4gylak
LNhR5cy1iPjdSSx6AbYae2JcVyV7yuLiF+9Jsp4Z8Mx2g4b8N5eVmNjGGGi7jgM9vqgEVRcIlhxz
saLjxVVRLC5H7GdRs0O9xKu46iUnT/4A7L4L/CW1nnUEAcGF7npyt/guAzwb4lrdm3wKjO2z2fu=