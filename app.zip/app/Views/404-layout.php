<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPt8edl7Ug6B6f/OBqXscO7Ez3S+V1qrBAU0vDJycbcQO6L5ErUmheUdcXuuiOefHZpFJMNP2
Z+ua6WS7afmto2ZJaBJEVBIavURbGjhXzXoO9oKfyHLLkb8GdHncolo7DkGWmG3j6mw4qOg+QAkK
nRB/y7Jnlq3whiohlj6JGBRHh2wskcf0ub23nRs5zbEST1LMhcjrpHn9Jiy23ZQLT1MZkzGPRZ2v
BUOj5LLWmp9u0YaNNJD6h4wpf3XqLgCc/K36KluVkXKfn/Dl+wmPRreavDj5QcbxR+gns55bbRdH
x2FePbDIIe0HPH/D9EvTFZKNvvvB4+HVCNi6K32EIDLepgQknQjKKxygjTvP3VJGzIpH1T0YDgTd
tTyXmTlQt02iHknX/qbTnO/3jjU0gplQJmtk4o7KC9DGIwmz8kq5L+PPM1XfWNDxBQuh/FRzdbc+
UtfdEDfQesWWAk21mRG4a/nJ3HGiZgIFiDi1cMD19VuOsXApjdZyqaJhwQ5/4wQ/jnztQ/kuQqke
r7RDr1R5s8ZFliKVXZKq8tPVYvsiJHAJdEpWsGuj71xiUzhngmhCjkaJ8FM8D33JNxPgOrxQj4K7
2ZGgM33pZVt2l5aM7c27cLgKDqWOauo2D5Y4BTP5uA0pbmqUPuHUOvRThuJjhS+1O6L4zOrHo1aO
a/FCZJQTekKE5CKEjfidS/UiJE7cXW7OK5DoLFum500uSS1NQjDMJuCKrFoPJ7mRoorVjRECpZq0
+557DOc1GfjMX9yiYixYLC4jVGivcq7Wk/eBWyxhBCT+B7o6PqhT/T/wCBuUNefKpUsYGAjzVd67
f4Pwck+A3cBjkyna2bJUvc7Kxdqvs7/ytLa1xDeR+nY0CoDvns9WXr+dzPjV0BiFoGRcp3qNOzuu
ODexlwpdcYNG6O6Xspa9iVudq7zO1H6wnmTpq+2I9C/mv59dlnlS8T1Y6KnDQhD3njEiggeBAh2o
o5M02+wxkfKUSe0A/opnWi6W1xqTJ6mtqQMCOZPhruhc46fBNrdHIaJdi6teKc0bTbFFZKHSuPGk
6RMAq0R9YcSAMsGEj+0IEE49LHQsU5PVFPH/Peq+xYy9joZ5juKcZcu5jUAbdQiN0Lf5cXd+kJdR
r1WP6tCnebExPrHO2BtooL1BQtVQWlvv17N/WMNGK/Cea1jWSEjdA3b0FbDd+eMdKX3ZwctSIFof
5iSonq3RUn8sBLVxWSHATF1e9xl5kAkeyN3kTofvGhwxi6DqzrW4h3fii9/mnNIZqBFLKi1J8ETE
H22FaMkICB3QPKx9WKTmY96kS6yzAcB8VX5Qc9rWDR+dABTF3Ld8K6F/ecP0N60NxXIKeXhScg/W
Uqav+fsjyJehMEYTvcAwOt9Dl+QPjvbO8ce6kRvJrEV86Mve6QsnFJExL74n4mseh9d+DKSfRJ92
r17JIKwCJtmCtftsyvTohfxTg7jSxTsyGQ1Co2YIwT+dcgx+kSN5tSjh3PLlsEZ05drWX+paiA1p
msTX6vzMSNwqcZ0+pixRmLBybH6F0qGTj5Zj97se6HgwTRXYMex4VipFN5/h0EG0rwkfRRd7VS5I
qe3+qOmvo+Lk+b5xMzDMcZYKdL9WD61SW4eK6ZVihphT8esxQbxLOzM5MhchByOHqN26eIPowdHV
rBO6jrOihSfSsi4zEV+dN0bXWVmIw4ySvkBtjpFi8B4hzemx4Z4IsUruvGW4FRoTxI3VNwmoq3Mh
6jAjdfOk/DU0yfV2vuwMwe2ES2pMcplJMpz1cJTV1udbwIQ3mYE3er9OrANEwLoipJOkpEt1GirF
2u8Lc8wnZJl/3G4R2n98CV45qU9E4jNC5h0k8x5pMlgwq1VtTrzB6lbDYuxbMuy8hUBGhsksrPYE
RYiQNiTGk0hns6aE+nwGJkBkTgNc8e9eX1o+j9Jo6KNyAwvHEhEY5FO+b9z5KSFD9AkVkLTnvJqp
1KQOIPvQzh7JJi7LpGHr8k3rVhwCX2ZSuXIQvamZC5h9OtAeQsyUNOyDMCA+wVNtHCqMk9+NBlwj
jlO5/RP2Wd8VfYPva6SKobMlwQz4h5Z+9341iP/5fOmn5tbLtFKfPoJwnQ4b+MGrHNTon4wZz/E4
DP5tFcZSvoc90Uxn+jGBz2oDGJgcq6hGpfErtliXXMz+Mk5HEs9tQE2g0IGKpZ5v+d1OYVJzRX6Q
aWfNAndyJM3oAWhJk66StOnYdSIf5ZRXfn9j7AvIabpXegy15DiqGG+nK4mi1+ai5f2DNwVdp3ej
TidENqSYZXcu0zs0ZAbHYkpBwWjTPq1VWoy0oNSZO7W4QMWJa7wOtLgoFNpKYgaUWRQkuOFcuyy5
q8eC4AluwKX8AGod2Qe+RIeaCbtJ2Zjki1a3c8xMXsphRBLLelYf0KE7V+djAEfzujMRemHIYg0t
scvvD7+PMalR45FjiAXuPxC0hOGqRkZlFsikNkJcVWX6c9q8iVNDqHX3L1NKP2mlmBy3feIut9/M
0aoVMn5pNDvUyO5KUQ8mvcuNWp56AIOXL93Kc6OSeeTBrJ/908wBJnRsjSFt342PDx6bRlgiHH9t
4pEja6NSHO/c0mpXyPUDdr51kTHLCq9j1t0KMkmhUJZfu2gXNULWPejIFNTR5vU76OB0BDEhPE08
jiJDTn0j0MaqsjNvTlDG2hA2z9ylo885S45K4CyDM9oKTTmd6fpPJB0emYVr1lYfN7d5Q0z3Qlm0
9kl7C1fB9jN/uaeLz5x0IUHPujI6D0u2/1QNQDLveHzltWPioEEe3aHrKrRqjOLCy+6OXf6eth6/
wSRnf7XUB97yrCnvf4LpKSas9E6DB406q1N6qd+qC5iUjd6pFVeuDozZK/wYwN3hL5LWyvAxSaoq
hj/8u8q=