<?php //0196b
// ***************************************************************************************************************************************************************************************************
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *    RRRRRRRRRRRRRRRRR                                        kkkkkkkk                                     tttt                    PPPPPPPPPPPPPPPPP   RRRRRRRRRRRRRRRRR        OOOOOOOOO         *
// *    R::::::::::::::::R                                       k::::::k                                  ttt:::t                    P::::::::::::::::P  R::::::::::::::::R     OO:::::::::OO       *
// *    R::::::RRRRRR:::::R                                      k::::::k                                  t:::::t                    P::::::PPPPPP:::::P R::::::RRRRRR:::::R  OO:::::::::::::OO     *
// *    RR:::::R     R:::::R                                     k::::::k                                  t:::::t                    PP:::::P     P:::::PRR:::::R     R:::::RO:::::::OOO:::::::O    *
// *      R::::R     R:::::R   ooooooooooo       cccccccccccccccc k:::::k    kkkkkkk eeeeeeeeeeee    ttttttt:::::ttttttt                P::::P     P:::::P  R::::R     R:::::RO::::::O   O::::::O    *
// *      R::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::c k:::::k   k:::::kee::::::::::::ee  t:::::::::::::::::t                P::::P     P:::::P  R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o:::::::::::::::o c:::::::::::::::::c k:::::k  k:::::ke::::::eeeee:::::eet:::::::::::::::::t                P::::PPPPPP:::::P   R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R:::::::::::::RR  o:::::ooooo:::::oc:::::::cccccc:::::c k:::::k k:::::ke::::::e     e:::::etttttt:::::::tttttt                P:::::::::::::PP    R:::::::::::::RR  O:::::O     O:::::O    *
// *      R::::RRRRRR:::::R o::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::eeeee::::::e      t:::::t                      P::::PPPPPPPPP      R::::RRRRRR:::::R O:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e:::::::::::::::::e       t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc:::::c              k:::::::::::k  e::::::eeeeeeeeeee        t:::::t                      P::::P              R::::R     R:::::RO:::::O     O:::::O    *
// *      R::::R     R:::::Ro::::o     o::::oc::::::c     ccccccc k::::::k:::::k e:::::::e                 t:::::t    tttttt            P::::P              R::::R     R:::::RO::::::O   O::::::O    *
// *    RR:::::R     R:::::Ro:::::ooooo:::::oc:::::::cccccc:::::ck::::::k k:::::ke::::::::e                t::::::tttt:::::t          PP::::::PP          RR:::::R     R:::::RO:::::::OOO:::::::O    *
// *    R::::::R     R:::::Ro:::::::::::::::o c:::::::::::::::::ck::::::k  k:::::ke::::::::eeeeeeee        tt::::::::::::::t          P::::::::P          R::::::R     R:::::R OO:::::::::::::OO     *
// *    R::::::R     R:::::R oo:::::::::::oo   cc:::::::::::::::ck::::::k   k:::::kee:::::::::::::e          tt:::::::::::tt          P::::::::P          R::::::R     R:::::R   OO:::::::::OO       *
// *    RRRRRRRR     RRRRRRR   ooooooooooo       cccccccccccccccckkkkkkkk    kkkkkkk eeeeeeeeeeeeee            ttttttttttt            PPPPPPPPPP          RRRRRRRR     RRRRRRR     OOOOOOOOO         *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// *                                                                                                                                                                                                 *
// ***************************************************************************************************************************************************************************************************
// 
// By Mahmoud AP
// 
// https://github.com/mahmoud-ap
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPusgoaMwASzgGtHVPX6y31mEcmP6NRJLelY8ymhiS2RJp6tL5NJwP4UcYfmum0tI58tj18pR
BB0dvYQsEwHeh8imZJ/asN/357SVRdcU6TYeK68Zg8wbZ3ew+bfZiWM1wpGc3dWMFq/I5SMzIzuV
8upiskfUzSREaObZ0+P3ngV3IDHLhYjB5d0aGOPzVrJ4dgLPv/LbeVHPk31Ta0Dp/ApVAuil1DK6
P1Bo2phM8haWd3CB4G1M3fX6dF4fdRsuHm8X4wSJRT5A8qsaufIGbchEIKGHOrVxhSddHyXZuDHn
BQovPSEWC1Fj7miwzhImGFOjOVXZwxATlsNeyyUEmWpTchRM/NcK6jAUpjpjakdd04GXTh3iGNic
surmb6JuJ4/dc1Q7rQNlUQq8THvtKtlXbUYWCf6EmoEbrVAhuk795K1dr2ACSNwtauzrJoctnvyB
c9LBL/+NPofXcj9bfYxpT8s+2EYn9JKV66CXIT6TU147C5TKcwhB6PCzdv4raLuKfWfTtAOEykcO
TH89lTkVSrOzYQ9JAb/IE+Oe4PBBYZTmB15t0ck5UtCxDPgbqiTIcxpBRSalc76Ip6yEwn6UDl+O
3PpbaCdbndGb3QxVlSFTun5zn5aa3kyMziJa6hcrqLyby0uFRm+XW6e0vKri2RgS5aAEIBbcdDck
pbwvjwM47UbN9HKfCb1LrGYvvEOpxOM2skPFVnznSooe6oSdYH8mcQZTC4CobJKdqXV6g44xEhhQ
ZwjPmMHZr52X9go+ekOQk4pcU3ul/5LlS8mHz88FDrBD8ey01uyYU1YcEX5lgH2P1LPEPdmMt3NL
h4VlueGHwvau5arDBQpDOgwWS6DBjx/PutXmIWYk0qLjpEUAQAPf8FvWvTJKm+ne99ZXJ3Eb8CY5
Dv1sqcynYgVkTGnHmRluffcYwJMvdvIrxSIT9z0IbKdn9YwB3pvDvWyX7mASSA4bzwGkjKlvqdDq
y9ftK5XcRniWYcuwuK3DpCSgoot6GctWPHZap2YzOsHqmmgUkDnbHPCDxHqGjy1XcjazZGpstmBI
a0DJHVyDwipxhmB9h8wf5hdO87JBAKS+lwNUha5IaeUJAHRFkncqnS5StBAOz9J9EEVbzowswt6U
hnsO8uR7cChXR+qUHeabPaG4unm6cFOsn5pRhfke5TTwTtmJdb88pSTr1oYHI/z9PYUjtVkTieui
LK0YP4SczDE3cQvBMDjFh5uNeKWgh5JCgU2SmzbWVoT68Xo305IgZthyJBBlEwVpmnMdv73Gq4Pu
RGaixtizERBySssLk4SCsVgkj9BpJh+zbuOAG3sqnfQsMmgMtbKYDqKKuATB8HOSZ+q71Ze0Pi5x
gN/0GpgRHxqU+dNGWMfSwB3P48hkNXPZDX+P2BG2x4lK762/z/dAmb5hc9a8bLv+HUldqX1BHrSO
5mDeZCrgGHePUPOqnUq5z8OYI3PN7cZH8Lquxgdj6xjdbf4JVGuN0uk5ry4u2bjUWsa/EJv1X05n
hzIgzhtSL8vFSN0+A7x7yZkHaEoeZgMZOyjui7G91sthbQiOCByrre29xajsBYQR25L/BEBSWzPM
ltx6+yMaPubsl7tpk5ynlG01C/UCnGJeSt5UWVs51KhHZZfkK4nQk8BQcvKuSs74yMS+C99PAc4H
IXYHGIoB3HIHGbiZAx2GU40LfxKb/mkWqD4ZYUIAA3ZTWUKFxlN3XNQY15zK54vCI9cAbKBpB/Os
u7kMhg18404LiGEMWJdi/oP47qwbR2Eql2bD3szVEq7PC+Hu8R3P/6SF9YLctS4+wWCLikM/iAtz
SrMtvkiHg9/lN8LnQvtDXtSK7Sa/58bG2gpejI1+HIVz7Ovk0D9FXYs4xn8xPAzdJqQvfS//maXe
uD486shJqPY4dipkkYCosFsz19bBqwLpW2aL6HFIw4G0AEtjxr9IYLnR+oZvG7OAOC+TrRvbdQrF
SoSHJbTNcKSU+dmFuHpzARzd+3wreVcdXyojjMAxsJ0gNo0DR0q+WIhZoM5E8pU5mdR/Eag+25w/
H2rQVWyZjTv0bY3lv4B214xhr8ObZclsulm15jhqL4Njdfn35ThG+n++nRiq2mUlWcfLEowK2zyQ
SWdfVfiqg5Pz33Vtp+sWzu1V8RL20AFBR5uBuz9MBqFW9SWOl1o6+YMOkOe4pQQ90MjgD5rUe0qD
VJXB+vOnpw8INCdziYcV10OBzb0eJcDDw7uz9goKkSiKdk6JAMUUbnpIX79IK4ROD91RcGnjcVNa
I71wnXtSxrKGHuQFxJ4R1cLgNfFFcZsyECGeQgi+ms0AubcSaNdNRgMIsFDEmQFuwfMY1Wemae+6
V7q8sQxzXqBuTyRqipP9ibSpzV8K3l/Gd890aAhMxQkb0TKIDA5s1qB2h2M857j6TSiwyY5YYI1l
VTOmACPk1MVGXuJew8gfeZahI1cuNXK0RusKNWurX4y+2dBL50byzTKdxX3fwhobt5yqOW9ggYnq
owVGWUg6WA8PVaVIgkIv4sSoW5SA0a0oAjKFaSI/Gw19kDmxWl3uBNtDBVzQ0VAXN8KWUsWCmxs1
G0zMfnThmOwDECVSms4Y8CBDqo1QFg2Cafx9Rw40lPMAkgFEDZ7JYmvWtWG0dYbVB3I1ZYa6dkcl
Q9CqzyOPM5puVRxTtGgk7GXlRfFkOM0KEubv+RFkXVMQjSTjl7JCHVQBhA7KWOWrTeClVAS4qyyw
JxrZ4XT2s74l0Bo24ivjhonpgQhLIOMZosfbYjakYRCP0+lCbabSMmkHmizNa5Y8rZ/bAzZNxx0f
k0DA8E3mJAaBRZHJ/5o6/K2lJCmUyZAQbaJqHF1aw35/fUIEcQ6x1cOGnPcBYoclHu61EIMs72b2
5M7wD0QeoB8Hym==